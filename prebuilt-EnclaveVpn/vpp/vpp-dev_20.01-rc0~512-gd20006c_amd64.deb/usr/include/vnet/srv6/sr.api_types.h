#ifndef included_sr_api_types_h
#define included_sr_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_srv6_sid {
    u8 addr[16];
} vl_api_srv6_sid_t;
typedef struct __attribute__ ((packed)) _vl_api_srv6_sid_list {
    u8 num_sids;
    u32 weight;
    vl_api_srv6_sid_t sids[16];
} vl_api_srv6_sid_list_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_ip6_address {
    u8 data[16];
} vl_api_sr_ip6_address_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_localsid_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_del;
    vl_api_srv6_sid_t localsid;
    u8 end_psp;
    u8 behavior;
    u32 sw_if_index;
    u32 vlan_index;
    u32 fib_table;
    u8 nh_addr6[16];
    u8 nh_addr4[4];
} vl_api_sr_localsid_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_localsid_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_localsid_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_policy_add {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 bsid_addr[16];
    u32 weight;
    u8 is_encap;
    u8 type;
    u32 fib_table;
    vl_api_srv6_sid_list_t sids;
} vl_api_sr_policy_add_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_policy_add_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_policy_add_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_policy_mod {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 bsid_addr[16];
    u32 sr_policy_index;
    u32 fib_table;
    u8 operation;
    u32 sl_index;
    u32 weight;
    vl_api_srv6_sid_list_t sids;
} vl_api_sr_policy_mod_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_policy_mod_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_policy_mod_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_policy_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_srv6_sid_t bsid_addr;
    u32 sr_policy_index;
} vl_api_sr_policy_del_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_policy_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_policy_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_set_encap_source {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 encaps_source[16];
} vl_api_sr_set_encap_source_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_set_encap_source_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_set_encap_source_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_set_encap_hop_limit {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 hop_limit;
} vl_api_sr_set_encap_hop_limit_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_set_encap_hop_limit_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_set_encap_hop_limit_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_steering_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_del;
    u8 bsid_addr[16];
    u32 sr_policy_index;
    u32 table_id;
    u8 prefix_addr[16];
    u32 mask_width;
    u32 sw_if_index;
    u8 traffic_type;
} vl_api_sr_steering_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_steering_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_steering_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_localsids_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_sr_localsids_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_localsids_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_srv6_sid_t addr;
    u8 end_psp;
    u16 behavior;
    u32 fib_table;
    u32 vlan_index;
    u8 xconnect_nh_addr6[16];
    u8 xconnect_nh_addr4[4];
    u32 xconnect_iface_or_vrf_table;
} vl_api_sr_localsids_details_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_policies_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_sr_policies_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_policies_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_srv6_sid_t bsid;
    u8 type;
    u8 is_encap;
    u32 fib_table;
    u8 num_sid_lists;
    vl_api_srv6_sid_list_t sid_lists[0];
} vl_api_sr_policies_details_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_steering_pol_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_sr_steering_pol_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_steering_pol_details {
    u16 _vl_msg_id;
    u32 context;
    u8 traffic_type;
    u32 fib_table;
    u8 prefix_addr[16];
    u32 mask_width;
    u32 sw_if_index;
    vl_api_srv6_sid_t bsid;
} vl_api_sr_steering_pol_details_t;

#endif

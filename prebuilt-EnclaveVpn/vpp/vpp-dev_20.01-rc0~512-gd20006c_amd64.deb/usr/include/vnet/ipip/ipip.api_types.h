#ifndef included_ipip_api_types_h
#define included_ipip_api_types_h
/* Imported API files */
#include <vnet/interface_types.api_types.h>
#include <vnet/ip/ip_types.api_types.h>
typedef struct __attribute__ ((packed)) _vl_api_ipip_tunnel {
    u32 instance;
    vl_api_address_t src;
    vl_api_address_t dst;
    vl_api_interface_index_t sw_if_index;
    u32 table_id;
    u8 tc_tos;
} vl_api_ipip_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_add_tunnel {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_ipip_tunnel_t tunnel;
} vl_api_ipip_add_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_add_tunnel_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    vl_api_interface_index_t sw_if_index;
} vl_api_ipip_add_tunnel_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_del_tunnel {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_interface_index_t sw_if_index;
} vl_api_ipip_del_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_del_tunnel_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipip_del_tunnel_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_6rd_add_tunnel {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ip6_table_id;
    u32 ip4_table_id;
    vl_api_ip6_prefix_t ip6_prefix;
    vl_api_ip4_prefix_t ip4_prefix;
    vl_api_ip4_address_t ip4_src;
    bool security_check;
    u8 tc_tos;
} vl_api_ipip_6rd_add_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_6rd_add_tunnel_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    vl_api_interface_index_t sw_if_index;
} vl_api_ipip_6rd_add_tunnel_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_6rd_del_tunnel {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_interface_index_t sw_if_index;
} vl_api_ipip_6rd_del_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_6rd_del_tunnel_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipip_6rd_del_tunnel_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_tunnel_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_interface_index_t sw_if_index;
} vl_api_ipip_tunnel_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipip_tunnel_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_ipip_tunnel_t tunnel;
} vl_api_ipip_tunnel_details_t;

#endif

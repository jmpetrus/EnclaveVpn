#ifndef included_lldp_api_types_h
#define included_lldp_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_lldp_config {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 system_name[256];
    u32 tx_hold;
    u32 tx_interval;
} vl_api_lldp_config_t;
typedef struct __attribute__ ((packed)) _vl_api_lldp_config_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lldp_config_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_lldp {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 port_desc[256];
    u8 mgmt_ip4[4];
    u8 mgmt_ip6[16];
    u8 mgmt_oid[128];
    u8 enable;
} vl_api_sw_interface_set_lldp_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_lldp_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sw_interface_set_lldp_reply_t;

#endif

/*
 * VLIB API definitions 2021-09-27 00:01:43
 * Input file: lldp.api
 * Automatically generated: please edit the input file NOT this file!
 */

#include <stdbool.h>
#if defined(vl_msg_id)||defined(vl_union_id) \
    || defined(vl_printfun) ||defined(vl_endianfun) \
    || defined(vl_api_version)||defined(vl_typedefs) \
    || defined(vl_msg_name)||defined(vl_msg_name_crc_list) \
    || defined(vl_api_version_tuple)
/* ok, something was selected */
#else
#warning no content included from lldp.api
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))
/* Imported API files */
#ifndef vl_api_version
#endif

/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_LLDP_CONFIG, vl_api_lldp_config_t_handler)
vl_msg_id(VL_API_LLDP_CONFIG_REPLY, vl_api_lldp_config_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_LLDP, vl_api_sw_interface_set_lldp_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_LLDP_REPLY, vl_api_sw_interface_set_lldp_reply_t_handler)
#endif
/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_lldp_config_t, 1)
vl_msg_name(vl_api_lldp_config_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_lldp_t, 1)
vl_msg_name(vl_api_sw_interface_set_lldp_reply_t, 1)
#endif
/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_lldp \
_(VL_API_LLDP_CONFIG, lldp_config, 2410286f) \
_(VL_API_LLDP_CONFIG_REPLY, lldp_config_reply, e8d4e804) \
_(VL_API_SW_INTERFACE_SET_LLDP, sw_interface_set_lldp, 2d85d156) \
_(VL_API_SW_INTERFACE_SET_LLDP_REPLY, sw_interface_set_lldp_reply, e8d4e804) 
#endif
/****** Typedefs ******/

#ifdef vl_typedefs
#include "lldp.api_types.h"
#endif
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_lldp_printfun_types
#define included_lldp_printfun_types


#endif
#endif /* vl_printfun_types */
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_lldp_printfun
#define included_lldp_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_lldp_config_t_print (vl_api_lldp_config_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_lldp_config_t: */
    s = format(s, "vl_api_lldp_config_t:");
    s = format(s, "\n%Usystem_name: %U", format_white_space, indent, format_hex_bytes, a, 256);
    s = format(s, "\n%Utx_hold: %u", format_white_space, indent, a->tx_hold);
    s = format(s, "\n%Utx_interval: %u", format_white_space, indent, a->tx_interval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_lldp_config_reply_t_print (vl_api_lldp_config_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_lldp_config_reply_t: */
    s = format(s, "vl_api_lldp_config_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_sw_interface_set_lldp_t_print (vl_api_sw_interface_set_lldp_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_sw_interface_set_lldp_t: */
    s = format(s, "vl_api_sw_interface_set_lldp_t:");
    s = format(s, "\n%Usw_if_index: %u", format_white_space, indent, a->sw_if_index);
    s = format(s, "\n%Uport_desc: %U", format_white_space, indent, format_hex_bytes, a, 256);
    s = format(s, "\n%Umgmt_ip4: %U", format_white_space, indent, format_hex_bytes, a, 4);
    s = format(s, "\n%Umgmt_ip6: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Umgmt_oid: %U", format_white_space, indent, format_hex_bytes, a, 128);
    s = format(s, "\n%Uenable: %u", format_white_space, indent, a->enable);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_sw_interface_set_lldp_reply_t_print (vl_api_sw_interface_set_lldp_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_sw_interface_set_lldp_reply_t: */
    s = format(s, "vl_api_sw_interface_set_lldp_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}


#endif
#endif /* vl_printfun */

/****** Endian swap functions *****/
#ifdef vl_endianfun
#ifndef included_lldp_endianfun
#define included_lldp_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_lldp_config_t_endian (vl_api_lldp_config_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->system_name = a->system_name (no-op) */
    a->tx_hold = clib_net_to_host_u32(a->tx_hold);
    a->tx_interval = clib_net_to_host_u32(a->tx_interval);
}

static inline void vl_api_lldp_config_reply_t_endian (vl_api_lldp_config_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_set_lldp_t_endian (vl_api_sw_interface_set_lldp_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->port_desc = a->port_desc (no-op) */
    /* a->mgmt_ip4 = a->mgmt_ip4 (no-op) */
    /* a->mgmt_ip6 = a->mgmt_ip6 (no-op) */
    /* a->mgmt_oid = a->mgmt_oid (no-op) */
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_sw_interface_set_lldp_reply_t_endian (vl_api_sw_interface_set_lldp_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}


#endif
#endif /* vl_endianfun */

/****** Version tuple *****/

#ifdef vl_api_version_tuple


#endif /* vl_api_version_tuple */

/****** API CRC (whole file) *****/

#ifdef vl_api_version
vl_api_version(lldp.api, 0xabb21dd0)

#endif


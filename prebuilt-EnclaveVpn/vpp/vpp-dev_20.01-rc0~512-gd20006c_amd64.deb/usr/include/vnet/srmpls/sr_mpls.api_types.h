#ifndef included_sr_mpls_api_types_h
#define included_sr_mpls_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_policy_add {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bsid;
    u32 weight;
    u8 type;
    u8 n_segments;
    u32 segments[0];
} vl_api_sr_mpls_policy_add_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_policy_add_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_mpls_policy_add_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_policy_mod {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bsid;
    u8 operation;
    u32 sl_index;
    u32 weight;
    u8 n_segments;
    u32 segments[0];
} vl_api_sr_mpls_policy_mod_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_policy_mod_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_mpls_policy_mod_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_policy_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bsid;
} vl_api_sr_mpls_policy_del_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_policy_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_mpls_policy_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_steering_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_del;
    u32 bsid;
    u32 table_id;
    u8 prefix_addr[16];
    u32 mask_width;
    u8 traffic_type;
    u8 next_hop[16];
    u8 nh_type;
    u32 color;
    u8 co_bits;
    u32 vpn_label;
} vl_api_sr_mpls_steering_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_steering_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_mpls_steering_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_policy_assign_endpoint_color {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bsid;
    u8 endpoint[16];
    u8 endpoint_type;
    u32 color;
} vl_api_sr_mpls_policy_assign_endpoint_color_t;
typedef struct __attribute__ ((packed)) _vl_api_sr_mpls_policy_assign_endpoint_color_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sr_mpls_policy_assign_endpoint_color_reply_t;

#endif

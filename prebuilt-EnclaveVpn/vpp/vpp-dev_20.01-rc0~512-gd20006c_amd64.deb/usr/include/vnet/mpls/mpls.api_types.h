#ifndef included_mpls_api_types_h
#define included_mpls_api_types_h
/* Imported API files */
#include <vnet/fib/fib_types.api_types.h>
#include <vnet/ip/ip_types.api_types.h>
typedef struct __attribute__ ((packed)) _vl_api_mpls_tunnel {
    u32 mt_sw_if_index;
    u32 mt_tunnel_index;
    u8 mt_l2_only;
    u8 mt_is_multicast;
    u8 mt_n_paths;
    vl_api_fib_path_t mt_paths[0];
} vl_api_mpls_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_table {
    u32 mt_table_id;
    u8 mt_name[64];
} vl_api_mpls_table_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_route {
    u32 mr_table_id;
    u32 mr_label;
    u8 mr_eos;
    u8 mr_eos_proto;
    u8 mr_is_multicast;
    u8 mr_n_paths;
    vl_api_fib_path_t mr_paths[0];
} vl_api_mpls_route_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_ip_bind_unbind {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 mb_mpls_table_id;
    u32 mb_label;
    u32 mb_ip_table_id;
    u8 mb_is_bind;
    vl_api_prefix_t mb_prefix;
} vl_api_mpls_ip_bind_unbind_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_ip_bind_unbind_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_mpls_ip_bind_unbind_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_tunnel_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mt_is_add;
    vl_api_mpls_tunnel_t mt_tunnel;
} vl_api_mpls_tunnel_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_tunnel_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
    u32 tunnel_index;
} vl_api_mpls_tunnel_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_tunnel_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
} vl_api_mpls_tunnel_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_tunnel_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_mpls_tunnel_t mt_tunnel;
} vl_api_mpls_tunnel_details_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_table_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mt_is_add;
    vl_api_mpls_table_t mt_table;
} vl_api_mpls_table_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_table_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_mpls_table_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_mpls_table_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_table_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_mpls_table_t mt_table;
} vl_api_mpls_table_details_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_route_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mr_is_add;
    u8 mr_is_multipath;
    vl_api_mpls_route_t mr_route;
} vl_api_mpls_route_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_route_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 stats_index;
} vl_api_mpls_route_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_route_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_mpls_table_t table;
} vl_api_mpls_route_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_mpls_route_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_mpls_route_t mr_route;
} vl_api_mpls_route_details_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_mpls_enable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 enable;
} vl_api_sw_interface_set_mpls_enable_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_mpls_enable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sw_interface_set_mpls_enable_reply_t;

#endif

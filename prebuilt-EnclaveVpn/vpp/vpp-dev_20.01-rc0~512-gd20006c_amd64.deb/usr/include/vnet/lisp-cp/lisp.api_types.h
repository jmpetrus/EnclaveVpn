#ifndef included_lisp_api_types_h
#define included_lisp_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_local_locator {
    u32 sw_if_index;
    u8 priority;
    u8 weight;
} vl_api_local_locator_t;
typedef struct __attribute__ ((packed)) _vl_api_remote_locator {
    u8 is_ip4;
    u8 priority;
    u8 weight;
    u8 addr[16];
} vl_api_remote_locator_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_adjacency {
    u8 eid_type;
    u8 reid[16];
    u8 leid[16];
    u8 reid_prefix_len;
    u8 leid_prefix_len;
} vl_api_lisp_adjacency_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
    u32 locator_num;
    vl_api_local_locator_t locators[0];
} vl_api_lisp_add_del_locator_set_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 ls_index;
} vl_api_lisp_add_del_locator_set_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_locator {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
    u32 sw_if_index;
    u8 priority;
    u8 weight;
} vl_api_lisp_add_del_locator_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_locator_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_add_del_locator_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_local_eid {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 eid_type;
    u8 eid[16];
    u8 prefix_len;
    u8 locator_set_name[64];
    u32 vni;
    u16 key_id;
    u8 key[64];
} vl_api_lisp_add_del_local_eid_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_local_eid_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_add_del_local_eid_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_map_server {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
} vl_api_lisp_add_del_map_server_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_map_server_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_add_del_map_server_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_map_resolver {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
} vl_api_lisp_add_del_map_resolver_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_map_resolver_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_add_del_map_resolver_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
} vl_api_lisp_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_pitr_set_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 ls_name[64];
} vl_api_lisp_pitr_set_locator_set_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_pitr_set_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_pitr_set_locator_set_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_use_petr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 address[16];
    u8 is_add;
} vl_api_lisp_use_petr_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_use_petr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_use_petr_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_use_petr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_lisp_use_petr_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_use_petr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 status;
    u8 is_ip4;
    u8 address[16];
} vl_api_show_lisp_use_petr_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_rloc_probe_state {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_lisp_rloc_probe_state_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_rloc_probe_state_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_enabled;
} vl_api_show_lisp_rloc_probe_state_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_rloc_probe_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
} vl_api_lisp_rloc_probe_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_rloc_probe_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_rloc_probe_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_map_register_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
} vl_api_lisp_map_register_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_map_register_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_map_register_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_map_register_state {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_lisp_map_register_state_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_map_register_state_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_enabled;
} vl_api_show_lisp_map_register_state_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_map_request_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mode;
} vl_api_lisp_map_request_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_map_request_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_map_request_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_map_request_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_lisp_map_request_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_map_request_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 mode;
} vl_api_show_lisp_map_request_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_remote_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_src_dst;
    u8 del_all;
    u32 vni;
    u8 action;
    u8 eid_type;
    u8 eid[16];
    u8 eid_len;
    u8 seid[16];
    u8 seid_len;
    u32 rloc_num;
    vl_api_remote_locator_t rlocs[0];
} vl_api_lisp_add_del_remote_mapping_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_remote_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_add_del_remote_mapping_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_adjacency {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 vni;
    u8 eid_type;
    u8 reid[16];
    u8 leid[16];
    u8 reid_len;
    u8 leid_len;
} vl_api_lisp_add_del_adjacency_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_adjacency_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_add_del_adjacency_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_map_request_itr_rlocs {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
} vl_api_lisp_add_del_map_request_itr_rlocs_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_add_del_map_request_itr_rlocs_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_add_del_map_request_itr_rlocs_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_eid_table_add_del_map {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 vni;
    u32 dp_table;
    u8 is_l2;
} vl_api_lisp_eid_table_add_del_map_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_eid_table_add_del_map_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_lisp_eid_table_add_del_map_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_locator_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ls_index;
    u8 ls_name[64];
    u8 is_index_set;
} vl_api_lisp_locator_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_locator_details {
    u16 _vl_msg_id;
    u32 context;
    u8 local;
    u32 sw_if_index;
    u8 is_ipv6;
    u8 ip_address[16];
    u8 priority;
    u8 weight;
} vl_api_lisp_locator_details_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_locator_set_details {
    u16 _vl_msg_id;
    u32 context;
    u32 ls_index;
    u8 ls_name[64];
} vl_api_lisp_locator_set_details_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_locator_set_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 filter;
} vl_api_lisp_locator_set_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_eid_table_details {
    u16 _vl_msg_id;
    u32 context;
    u32 locator_set_index;
    u8 action;
    u8 is_local;
    u8 eid_type;
    u8 is_src_dst;
    u32 vni;
    u8 eid[16];
    u8 eid_prefix_len;
    u8 seid[16];
    u8 seid_prefix_len;
    u32 ttl;
    u8 authoritative;
    u16 key_id;
    u8 key[64];
} vl_api_lisp_eid_table_details_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_eid_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 eid_set;
    u8 prefix_length;
    u32 vni;
    u8 eid_type;
    u8 eid[16];
    u8 filter;
} vl_api_lisp_eid_table_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_adjacencies_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_lisp_adjacency_t adjacencies[0];
} vl_api_lisp_adjacencies_get_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_adjacencies_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vni;
} vl_api_lisp_adjacencies_get_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_eid_table_map_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vni;
    u32 dp_table;
} vl_api_lisp_eid_table_map_details_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_eid_table_map_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_l2;
} vl_api_lisp_eid_table_map_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_eid_table_vni_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_lisp_eid_table_vni_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_eid_table_vni_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vni;
} vl_api_lisp_eid_table_vni_details_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_map_resolver_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ipv6;
    u8 ip_address[16];
} vl_api_lisp_map_resolver_details_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_map_resolver_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_lisp_map_resolver_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_map_server_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ipv6;
    u8 ip_address[16];
} vl_api_lisp_map_server_details_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_map_server_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_lisp_map_server_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_status {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_lisp_status_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_status_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 feature_status;
    u8 gpe_status;
} vl_api_show_lisp_status_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_get_map_request_itr_rlocs {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_lisp_get_map_request_itr_rlocs_t;
typedef struct __attribute__ ((packed)) _vl_api_lisp_get_map_request_itr_rlocs_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 locator_set_name[64];
} vl_api_lisp_get_map_request_itr_rlocs_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_pitr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_lisp_pitr_t;
typedef struct __attribute__ ((packed)) _vl_api_show_lisp_pitr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 status;
    u8 locator_set_name[64];
} vl_api_show_lisp_pitr_reply_t;

#endif

#ifndef included_one_api_types_h
#define included_one_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_one_local_locator {
    u32 sw_if_index;
    u8 priority;
    u8 weight;
} vl_api_one_local_locator_t;
typedef struct __attribute__ ((packed)) _vl_api_one_remote_locator {
    u8 is_ip4;
    u8 priority;
    u8 weight;
    u8 addr[16];
} vl_api_one_remote_locator_t;
typedef struct __attribute__ ((packed)) _vl_api_one_l2_arp_entry {
    u8 mac[6];
    u32 ip4;
} vl_api_one_l2_arp_entry_t;
typedef struct __attribute__ ((packed)) _vl_api_one_ndp_entry {
    u8 mac[6];
    u8 ip6[16];
} vl_api_one_ndp_entry_t;
typedef struct __attribute__ ((packed)) _vl_api_one_adjacency {
    u8 eid_type;
    u8 reid[16];
    u8 leid[16];
    u8 reid_prefix_len;
    u8 leid_prefix_len;
} vl_api_one_adjacency_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
    u32 locator_num;
    vl_api_one_local_locator_t locators[0];
} vl_api_one_add_del_locator_set_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 ls_index;
} vl_api_one_add_del_locator_set_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_locator {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
    u32 sw_if_index;
    u8 priority;
    u8 weight;
} vl_api_one_add_del_locator_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_locator_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_locator_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_local_eid {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 eid_type;
    u8 eid[16];
    u8 prefix_len;
    u8 locator_set_name[64];
    u32 vni;
    u16 key_id;
    u8 key[64];
} vl_api_one_add_del_local_eid_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_local_eid_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_local_eid_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_register_set_ttl {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ttl;
} vl_api_one_map_register_set_ttl_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_register_set_ttl_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_map_register_set_ttl_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_map_register_ttl {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_map_register_ttl_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_map_register_ttl_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 ttl;
} vl_api_show_one_map_register_ttl_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_map_server {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
} vl_api_one_add_del_map_server_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_map_server_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_map_server_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_map_resolver {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
} vl_api_one_add_del_map_resolver_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_map_resolver_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_map_resolver_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
} vl_api_one_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_one_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_nsh_set_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 ls_name[64];
} vl_api_one_nsh_set_locator_set_t;
typedef struct __attribute__ ((packed)) _vl_api_one_nsh_set_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_nsh_set_locator_set_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_pitr_set_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 ls_name[64];
} vl_api_one_pitr_set_locator_set_t;
typedef struct __attribute__ ((packed)) _vl_api_one_pitr_set_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_pitr_set_locator_set_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_use_petr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 address[16];
    u8 is_add;
} vl_api_one_use_petr_t;
typedef struct __attribute__ ((packed)) _vl_api_one_use_petr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_use_petr_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_use_petr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_use_petr_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_use_petr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 status;
    u8 is_ip4;
    u8 address[16];
} vl_api_show_one_use_petr_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_rloc_probe_state {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_rloc_probe_state_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_rloc_probe_state_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_enabled;
} vl_api_show_one_rloc_probe_state_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_rloc_probe_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
} vl_api_one_rloc_probe_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_one_rloc_probe_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_rloc_probe_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_register_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
} vl_api_one_map_register_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_register_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_map_register_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_map_register_state {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_map_register_state_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_map_register_state_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_enabled;
} vl_api_show_one_map_register_state_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_request_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mode;
} vl_api_one_map_request_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_request_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_map_request_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_map_request_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_map_request_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_map_request_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 mode;
} vl_api_show_one_map_request_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_remote_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_src_dst;
    u8 del_all;
    u32 vni;
    u8 action;
    u8 eid_type;
    u8 eid[16];
    u8 eid_len;
    u8 seid[16];
    u8 seid_len;
    u32 rloc_num;
    vl_api_one_remote_locator_t rlocs[0];
} vl_api_one_add_del_remote_mapping_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_remote_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_remote_mapping_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_l2_arp_entry {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 mac[6];
    u32 bd;
    u32 ip4;
} vl_api_one_add_del_l2_arp_entry_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_l2_arp_entry_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_l2_arp_entry_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_l2_arp_entries_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd;
} vl_api_one_l2_arp_entries_get_t;
typedef struct __attribute__ ((packed)) _vl_api_one_l2_arp_entries_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_one_l2_arp_entry_t entries[0];
} vl_api_one_l2_arp_entries_get_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_ndp_entry {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 mac[6];
    u32 bd;
    u8 ip6[16];
} vl_api_one_add_del_ndp_entry_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_ndp_entry_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_ndp_entry_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_ndp_entries_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd;
} vl_api_one_ndp_entries_get_t;
typedef struct __attribute__ ((packed)) _vl_api_one_ndp_entries_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_one_ndp_entry_t entries[0];
} vl_api_one_ndp_entries_get_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_set_transport_protocol {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 protocol;
} vl_api_one_set_transport_protocol_t;
typedef struct __attribute__ ((packed)) _vl_api_one_set_transport_protocol_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_set_transport_protocol_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_get_transport_protocol {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_get_transport_protocol_t;
typedef struct __attribute__ ((packed)) _vl_api_one_get_transport_protocol_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 protocol;
} vl_api_one_get_transport_protocol_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_ndp_bd_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_ndp_bd_get_t;
typedef struct __attribute__ ((packed)) _vl_api_one_ndp_bd_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    u32 bridge_domains[0];
} vl_api_one_ndp_bd_get_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_l2_arp_bd_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_l2_arp_bd_get_t;
typedef struct __attribute__ ((packed)) _vl_api_one_l2_arp_bd_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    u32 bridge_domains[0];
} vl_api_one_l2_arp_bd_get_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_adjacency {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 vni;
    u8 eid_type;
    u8 reid[16];
    u8 leid[16];
    u8 reid_len;
    u8 leid_len;
} vl_api_one_add_del_adjacency_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_adjacency_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_adjacency_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_map_request_itr_rlocs {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
} vl_api_one_add_del_map_request_itr_rlocs_t;
typedef struct __attribute__ ((packed)) _vl_api_one_add_del_map_request_itr_rlocs_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_add_del_map_request_itr_rlocs_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_eid_table_add_del_map {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 vni;
    u32 dp_table;
    u8 is_l2;
} vl_api_one_eid_table_add_del_map_t;
typedef struct __attribute__ ((packed)) _vl_api_one_eid_table_add_del_map_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_eid_table_add_del_map_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_locator_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ls_index;
    u8 ls_name[64];
    u8 is_index_set;
} vl_api_one_locator_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_one_locator_details {
    u16 _vl_msg_id;
    u32 context;
    u8 local;
    u32 sw_if_index;
    u8 is_ipv6;
    u8 ip_address[16];
    u8 priority;
    u8 weight;
} vl_api_one_locator_details_t;
typedef struct __attribute__ ((packed)) _vl_api_one_locator_set_details {
    u16 _vl_msg_id;
    u32 context;
    u32 ls_index;
    u8 ls_name[64];
} vl_api_one_locator_set_details_t;
typedef struct __attribute__ ((packed)) _vl_api_one_locator_set_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 filter;
} vl_api_one_locator_set_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_one_eid_table_details {
    u16 _vl_msg_id;
    u32 context;
    u32 locator_set_index;
    u8 action;
    u8 is_local;
    u8 eid_type;
    u8 is_src_dst;
    u32 vni;
    u8 eid[16];
    u8 eid_prefix_len;
    u8 seid[16];
    u8 seid_prefix_len;
    u32 ttl;
    u8 authoritative;
    u16 key_id;
    u8 key[64];
} vl_api_one_eid_table_details_t;
typedef struct __attribute__ ((packed)) _vl_api_one_eid_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 eid_set;
    u8 prefix_length;
    u32 vni;
    u8 eid_type;
    u8 eid[16];
    u8 filter;
} vl_api_one_eid_table_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_one_adjacencies_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_one_adjacency_t adjacencies[0];
} vl_api_one_adjacencies_get_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_adjacencies_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vni;
} vl_api_one_adjacencies_get_t;
typedef struct __attribute__ ((packed)) _vl_api_one_eid_table_map_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vni;
    u32 dp_table;
} vl_api_one_eid_table_map_details_t;
typedef struct __attribute__ ((packed)) _vl_api_one_eid_table_map_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_l2;
} vl_api_one_eid_table_map_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_one_eid_table_vni_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_eid_table_vni_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_one_eid_table_vni_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vni;
} vl_api_one_eid_table_vni_details_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_resolver_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ipv6;
    u8 ip_address[16];
} vl_api_one_map_resolver_details_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_resolver_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_map_resolver_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_server_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ipv6;
    u8 ip_address[16];
} vl_api_one_map_server_details_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_server_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_map_server_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_status {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_status_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_status_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 feature_status;
    u8 gpe_status;
} vl_api_show_one_status_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_get_map_request_itr_rlocs {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_get_map_request_itr_rlocs_t;
typedef struct __attribute__ ((packed)) _vl_api_one_get_map_request_itr_rlocs_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 locator_set_name[64];
} vl_api_one_get_map_request_itr_rlocs_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_nsh_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_nsh_mapping_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_nsh_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_set;
    u8 locator_set_name[64];
} vl_api_show_one_nsh_mapping_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_pitr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_pitr_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_pitr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 status;
    u8 locator_set_name[64];
} vl_api_show_one_pitr_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_stats_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_stats_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_one_stats_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vni;
    u8 eid_type;
    u8 deid[16];
    u8 seid[16];
    u8 deid_pref_len;
    u8 seid_pref_len;
    u8 is_ip4;
    u8 rloc[16];
    u8 lloc[16];
    u32 pkt_count;
    u32 bytes;
} vl_api_one_stats_details_t;
typedef struct __attribute__ ((packed)) _vl_api_one_stats_flush {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_stats_flush_t;
typedef struct __attribute__ ((packed)) _vl_api_one_stats_flush_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_stats_flush_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_stats_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
} vl_api_one_stats_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_one_stats_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_stats_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_stats_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_stats_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_stats_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_en;
} vl_api_show_one_stats_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_register_fallback_threshold {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 value;
} vl_api_one_map_register_fallback_threshold_t;
typedef struct __attribute__ ((packed)) _vl_api_one_map_register_fallback_threshold_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_map_register_fallback_threshold_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_map_register_fallback_threshold {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_show_one_map_register_fallback_threshold_t;
typedef struct __attribute__ ((packed)) _vl_api_show_one_map_register_fallback_threshold_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 value;
} vl_api_show_one_map_register_fallback_threshold_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_enable_disable_xtr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
} vl_api_one_enable_disable_xtr_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_one_enable_disable_xtr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_enable_disable_xtr_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_show_xtr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_show_xtr_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_one_show_xtr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_en;
} vl_api_one_show_xtr_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_enable_disable_petr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
} vl_api_one_enable_disable_petr_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_one_enable_disable_petr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_enable_disable_petr_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_show_petr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_show_petr_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_one_show_petr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_en;
} vl_api_one_show_petr_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_enable_disable_pitr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
} vl_api_one_enable_disable_pitr_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_one_enable_disable_pitr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_one_enable_disable_pitr_mode_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_one_show_pitr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_one_show_pitr_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_one_show_pitr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_en;
} vl_api_one_show_pitr_mode_reply_t;

#endif

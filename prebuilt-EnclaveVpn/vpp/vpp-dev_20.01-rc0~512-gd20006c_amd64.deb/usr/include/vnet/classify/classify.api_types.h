#ifndef included_classify_api_types_h
#define included_classify_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_classify_add_del_table {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 del_chain;
    u32 table_index;
    u32 nbuckets;
    u32 memory_size;
    u32 skip_n_vectors;
    u32 match_n_vectors;
    u32 next_table_index;
    u32 miss_next_index;
    u32 current_data_flag;
    i32 current_data_offset;
    u32 mask_len;
    u8 mask[0];
} vl_api_classify_add_del_table_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_add_del_table_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 new_table_index;
    u32 skip_n_vectors;
    u32 match_n_vectors;
} vl_api_classify_add_del_table_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_add_del_session {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 table_index;
    u32 hit_next_index;
    u32 opaque_index;
    i32 advance;
    u8 action;
    u32 metadata;
    u32 match_len;
    u8 match[0];
} vl_api_classify_add_del_session_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_add_del_session_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_classify_add_del_session_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_policer_classify_set_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 ip4_table_index;
    u32 ip6_table_index;
    u32 l2_table_index;
    u8 is_add;
} vl_api_policer_classify_set_interface_t;
typedef struct __attribute__ ((packed)) _vl_api_policer_classify_set_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_policer_classify_set_interface_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_policer_classify_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 type;
} vl_api_policer_classify_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_policer_classify_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u32 table_index;
} vl_api_policer_classify_details_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_table_ids {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_classify_table_ids_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_table_ids_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    u32 ids[0];
} vl_api_classify_table_ids_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_table_by_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
} vl_api_classify_table_by_interface_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_table_by_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
    u32 l2_table_id;
    u32 ip4_table_id;
    u32 ip6_table_id;
} vl_api_classify_table_by_interface_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_table_info {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 table_id;
} vl_api_classify_table_info_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_table_info_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 table_id;
    u32 nbuckets;
    u32 match_n_vectors;
    u32 skip_n_vectors;
    u32 active_sessions;
    u32 next_table_index;
    u32 miss_next_index;
    u32 mask_length;
    u8 mask[0];
} vl_api_classify_table_info_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_session_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 table_id;
} vl_api_classify_session_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_session_details {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 table_id;
    u32 hit_next_index;
    i32 advance;
    u32 opaque_index;
    u32 match_length;
    u8 match[0];
} vl_api_classify_session_details_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_classify_set_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 ip4_table_index;
    u32 ip6_table_index;
    u8 is_add;
} vl_api_flow_classify_set_interface_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_classify_set_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_flow_classify_set_interface_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_classify_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 type;
} vl_api_flow_classify_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_classify_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u32 table_index;
} vl_api_flow_classify_details_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_set_interface_ip_table {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ipv6;
    u32 sw_if_index;
    u32 table_index;
} vl_api_classify_set_interface_ip_table_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_set_interface_ip_table_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_classify_set_interface_ip_table_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_set_interface_l2_tables {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 ip4_table_index;
    u32 ip6_table_index;
    u32 other_table_index;
    u8 is_input;
} vl_api_classify_set_interface_l2_tables_t;
typedef struct __attribute__ ((packed)) _vl_api_classify_set_interface_l2_tables_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_classify_set_interface_l2_tables_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_input_acl_set_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 ip4_table_index;
    u32 ip6_table_index;
    u32 l2_table_index;
    u8 is_add;
} vl_api_input_acl_set_interface_t;
typedef struct __attribute__ ((packed)) _vl_api_input_acl_set_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_input_acl_set_interface_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_output_acl_set_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 ip4_table_index;
    u32 ip6_table_index;
    u32 l2_table_index;
    u8 is_add;
} vl_api_output_acl_set_interface_t;
typedef struct __attribute__ ((packed)) _vl_api_output_acl_set_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_output_acl_set_interface_reply_t;

#endif

#ifndef included_pg_api_types_h
#define included_pg_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_pg_create_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 interface_id;
    u8 gso_enabled;
    u32 gso_size;
} vl_api_pg_create_interface_t;
typedef struct __attribute__ ((packed)) _vl_api_pg_create_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
} vl_api_pg_create_interface_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_pg_capture {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 interface_id;
    u8 is_enabled;
    u32 count;
    u32 pcap_name_length;
    u8 pcap_file_name[0];
} vl_api_pg_capture_t;
typedef struct __attribute__ ((packed)) _vl_api_pg_capture_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_pg_capture_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_pg_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
    u32 stream_name_length;
    u8 stream_name[0];
} vl_api_pg_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_pg_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_pg_enable_disable_reply_t;

#endif

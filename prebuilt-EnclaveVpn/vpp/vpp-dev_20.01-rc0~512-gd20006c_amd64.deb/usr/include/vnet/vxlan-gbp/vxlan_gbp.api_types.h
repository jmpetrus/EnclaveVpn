#ifndef included_vxlan_gbp_api_types_h
#define included_vxlan_gbp_api_types_h
/* Imported API files */
#include <vnet/ip/ip_types.api_types.h>
typedef enum {
    VXLAN_GBP_API_TUNNEL_MODE_L2 = 1,
    VXLAN_GBP_API_TUNNEL_MODE_L3 = 2,
} vl_api_vxlan_gbp_api_tunnel_mode_t;
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gbp_tunnel {
    u32 instance;
    vl_api_address_t src;
    vl_api_address_t dst;
    u32 mcast_sw_if_index;
    u32 encap_table_id;
    u32 vni;
    u32 sw_if_index;
    vl_api_vxlan_gbp_api_tunnel_mode_t mode;
} vl_api_vxlan_gbp_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gbp_tunnel_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    vl_api_vxlan_gbp_tunnel_t tunnel;
} vl_api_vxlan_gbp_tunnel_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gbp_tunnel_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
} vl_api_vxlan_gbp_tunnel_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gbp_tunnel_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
} vl_api_vxlan_gbp_tunnel_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gbp_tunnel_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_vxlan_gbp_tunnel_t tunnel;
} vl_api_vxlan_gbp_tunnel_details_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_vxlan_gbp_bypass {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_ipv6;
    u8 enable;
} vl_api_sw_interface_set_vxlan_gbp_bypass_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_vxlan_gbp_bypass_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sw_interface_set_vxlan_gbp_bypass_reply_t;

#endif

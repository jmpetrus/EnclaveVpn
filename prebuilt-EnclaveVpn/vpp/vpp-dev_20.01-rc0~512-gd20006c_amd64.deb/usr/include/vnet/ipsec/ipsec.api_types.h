#ifndef included_ipsec_api_types_h
#define included_ipsec_api_types_h
/* Imported API files */
#include <vnet/ip/ip_types.api_types.h>
#include <vnet/interface_types.api_types.h>
typedef enum {
    IPSEC_API_SPD_ACTION_BYPASS = 0,
    IPSEC_API_SPD_ACTION_DISCARD = 1,
    IPSEC_API_SPD_ACTION_RESOLVE = 2,
    IPSEC_API_SPD_ACTION_PROTECT = 3,
} vl_api_ipsec_spd_action_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_entry {
    u32 spd_id;
    i32 priority;
    u8 is_outbound;
    u32 sa_id;
    vl_api_ipsec_spd_action_t policy;
    u8 protocol;
    vl_api_address_t remote_address_start;
    vl_api_address_t remote_address_stop;
    vl_api_address_t local_address_start;
    vl_api_address_t local_address_stop;
    u16 remote_port_start;
    u16 remote_port_stop;
    u16 local_port_start;
    u16 local_port_stop;
} vl_api_ipsec_spd_entry_t;
typedef enum {
    IPSEC_API_CRYPTO_ALG_NONE = 0,
    IPSEC_API_CRYPTO_ALG_AES_CBC_128 = 1,
    IPSEC_API_CRYPTO_ALG_AES_CBC_192 = 2,
    IPSEC_API_CRYPTO_ALG_AES_CBC_256 = 3,
    IPSEC_API_CRYPTO_ALG_AES_CTR_128 = 4,
    IPSEC_API_CRYPTO_ALG_AES_CTR_192 = 5,
    IPSEC_API_CRYPTO_ALG_AES_CTR_256 = 6,
    IPSEC_API_CRYPTO_ALG_AES_GCM_128 = 7,
    IPSEC_API_CRYPTO_ALG_AES_GCM_192 = 8,
    IPSEC_API_CRYPTO_ALG_AES_GCM_256 = 9,
    IPSEC_API_CRYPTO_ALG_DES_CBC = 10,
    IPSEC_API_CRYPTO_ALG_3DES_CBC = 11,
} vl_api_ipsec_crypto_alg_t;
typedef enum {
    IPSEC_API_INTEG_ALG_NONE = 0,
    IPSEC_API_INTEG_ALG_MD5_96 = 1,
    IPSEC_API_INTEG_ALG_SHA1_96 = 2,
    IPSEC_API_INTEG_ALG_SHA_256_96 = 3,
    IPSEC_API_INTEG_ALG_SHA_256_128 = 4,
    IPSEC_API_INTEG_ALG_SHA_384_192 = 5,
    IPSEC_API_INTEG_ALG_SHA_512_256 = 6,
} vl_api_ipsec_integ_alg_t;
typedef enum {
    IPSEC_API_SAD_FLAG_NONE = 0,
    IPSEC_API_SAD_FLAG_USE_ESN = 1,
    IPSEC_API_SAD_FLAG_USE_ANTI_REPLAY = 2,
    IPSEC_API_SAD_FLAG_IS_TUNNEL = 4,
    IPSEC_API_SAD_FLAG_IS_TUNNEL_V6 = 8,
    IPSEC_API_SAD_FLAG_UDP_ENCAP = 16,
} vl_api_ipsec_sad_flags_t;
typedef enum {
    IPSEC_API_PROTO_ESP = 1,
    IPSEC_API_PROTO_AH = 2,
} vl_api_ipsec_proto_t;
typedef struct __attribute__ ((packed)) _vl_api_key {
    u8 length;
    u8 data[128];
} vl_api_key_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_sad_entry {
    u32 sad_id;
    u32 spi;
    vl_api_ipsec_proto_t protocol;
    vl_api_ipsec_crypto_alg_t crypto_algorithm;
    vl_api_key_t crypto_key;
    vl_api_ipsec_integ_alg_t integrity_algorithm;
    vl_api_key_t integrity_key;
    vl_api_ipsec_sad_flags_t flags;
    vl_api_address_t tunnel_src;
    vl_api_address_t tunnel_dst;
    u32 tx_table_id;
    u32 salt;
} vl_api_ipsec_sad_entry_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_protect {
    vl_api_interface_index_t sw_if_index;
    u32 sa_out;
    u8 n_sa_in;
    u32 sa_in[0];
} vl_api_ipsec_tunnel_protect_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 spd_id;
} vl_api_ipsec_spd_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipsec_spd_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_interface_add_del_spd {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 sw_if_index;
    u32 spd_id;
} vl_api_ipsec_interface_add_del_spd_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_interface_add_del_spd_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipsec_interface_add_del_spd_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_entry_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    vl_api_ipsec_spd_entry_t entry;
} vl_api_ipsec_spd_entry_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_entry_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 stat_index;
} vl_api_ipsec_spd_entry_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spds_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_ipsec_spds_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spds_details {
    u16 _vl_msg_id;
    u32 context;
    u32 spd_id;
    u32 npolicies;
} vl_api_ipsec_spds_details_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 spd_id;
    u32 sa_id;
} vl_api_ipsec_spd_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_ipsec_spd_entry_t entry;
} vl_api_ipsec_spd_details_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_sad_entry_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    vl_api_ipsec_sad_entry_t entry;
} vl_api_ipsec_sad_entry_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_sad_entry_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 stat_index;
} vl_api_ipsec_sad_entry_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_protect_update {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_ipsec_tunnel_protect_t tunnel;
} vl_api_ipsec_tunnel_protect_update_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_protect_update_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipsec_tunnel_protect_update_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_protect_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_interface_index_t sw_if_index;
} vl_api_ipsec_tunnel_protect_del_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_protect_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipsec_tunnel_protect_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_protect_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_interface_index_t sw_if_index;
} vl_api_ipsec_tunnel_protect_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_protect_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_ipsec_tunnel_protect_t tun;
} vl_api_ipsec_tunnel_protect_details_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_interface_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 spd_index;
    u8 spd_index_valid;
} vl_api_ipsec_spd_interface_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_spd_interface_details {
    u16 _vl_msg_id;
    u32 context;
    u32 spd_index;
    u32 sw_if_index;
} vl_api_ipsec_spd_interface_details_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_if_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 esn;
    u8 anti_replay;
    vl_api_address_t local_ip;
    vl_api_address_t remote_ip;
    u32 local_spi;
    u32 remote_spi;
    u8 crypto_alg;
    u8 local_crypto_key_len;
    u8 local_crypto_key[128];
    u8 remote_crypto_key_len;
    u8 remote_crypto_key[128];
    u8 integ_alg;
    u8 local_integ_key_len;
    u8 local_integ_key[128];
    u8 remote_integ_key_len;
    u8 remote_integ_key[128];
    u8 renumber;
    u32 show_instance;
    u8 udp_encap;
    u32 tx_table_id;
    u32 salt;
} vl_api_ipsec_tunnel_if_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_if_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
} vl_api_ipsec_tunnel_if_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_sa_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sa_id;
} vl_api_ipsec_sa_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_sa_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_ipsec_sad_entry_t entry;
    u32 sw_if_index;
    u32 salt;
    u64 seq_outbound;
    u64 last_seq_inbound;
    u64 replay_window;
    u64 total_data_size;
} vl_api_ipsec_sa_details_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_if_set_sa {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 sa_id;
    u8 is_outbound;
} vl_api_ipsec_tunnel_if_set_sa_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_tunnel_if_set_sa_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipsec_tunnel_if_set_sa_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_backend_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_ipsec_backend_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_backend_details {
    u16 _vl_msg_id;
    u32 context;
    u8 name[128];
    vl_api_ipsec_proto_t protocol;
    u8 index;
    u8 active;
} vl_api_ipsec_backend_details_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_select_backend {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_ipsec_proto_t protocol;
    u8 index;
} vl_api_ipsec_select_backend_t;
typedef struct __attribute__ ((packed)) _vl_api_ipsec_select_backend_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipsec_select_backend_reply_t;

#endif

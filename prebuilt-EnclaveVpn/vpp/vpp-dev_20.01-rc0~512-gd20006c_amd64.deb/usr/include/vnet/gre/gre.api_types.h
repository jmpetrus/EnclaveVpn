#ifndef included_gre_api_types_h
#define included_gre_api_types_h
/* Imported API files */
#include <vnet/interface_types.api_types.h>
#include <vnet/ip/ip_types.api_types.h>
typedef enum {
    GRE_API_TUNNEL_TYPE_L3 = 0,
    GRE_API_TUNNEL_TYPE_TEB = 1,
    GRE_API_TUNNEL_TYPE_ERSPAN = 2,
} vl_api_gre_tunnel_type_t;
typedef struct __attribute__ ((packed)) _vl_api_gre_tunnel {
    u32 client_index;
    u32 context;
    u16 session_id;
    vl_api_gre_tunnel_type_t type;
    u32 instance;
    u32 outer_fib_id;
    vl_api_interface_index_t sw_if_index;
    vl_api_address_t src;
    vl_api_address_t dst;
} vl_api_gre_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_gre_tunnel_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    bool is_add;
    vl_api_gre_tunnel_t tunnel;
} vl_api_gre_tunnel_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_gre_tunnel_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    vl_api_interface_index_t sw_if_index;
} vl_api_gre_tunnel_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_gre_tunnel_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_interface_index_t sw_if_index;
} vl_api_gre_tunnel_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_gre_tunnel_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_gre_tunnel_t tunnel;
} vl_api_gre_tunnel_details_t;

#endif

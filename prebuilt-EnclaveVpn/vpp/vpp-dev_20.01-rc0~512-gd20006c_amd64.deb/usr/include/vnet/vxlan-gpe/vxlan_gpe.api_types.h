#ifndef included_vxlan_gpe_api_types_h
#define included_vxlan_gpe_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gpe_add_del_tunnel {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ipv6;
    u8 local[16];
    u8 remote[16];
    u32 mcast_sw_if_index;
    u32 encap_vrf_id;
    u32 decap_vrf_id;
    u8 protocol;
    u32 vni;
    u8 is_add;
} vl_api_vxlan_gpe_add_del_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gpe_add_del_tunnel_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
} vl_api_vxlan_gpe_add_del_tunnel_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gpe_tunnel_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
} vl_api_vxlan_gpe_tunnel_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_vxlan_gpe_tunnel_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u8 local[16];
    u8 remote[16];
    u32 vni;
    u8 protocol;
    u32 mcast_sw_if_index;
    u32 encap_vrf_id;
    u32 decap_vrf_id;
    u8 is_ipv6;
} vl_api_vxlan_gpe_tunnel_details_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_vxlan_gpe_bypass {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_ipv6;
    u8 enable;
} vl_api_sw_interface_set_vxlan_gpe_bypass_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_vxlan_gpe_bypass_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sw_interface_set_vxlan_gpe_bypass_reply_t;

#endif

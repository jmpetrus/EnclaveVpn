#ifndef included_session_api_types_h
#define included_session_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_application_attach {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 initial_segment_size;
    u64 options[16];
    u8 namespace_id_len;
    u8 namespace_id[64];
} vl_api_application_attach_t;
typedef struct __attribute__ ((packed)) _vl_api_application_attach_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 app_event_queue_address;
    u8 n_fds;
    u8 fd_flags;
    u32 segment_size;
    u8 segment_name_length;
    u8 segment_name[128];
    u32 app_index;
    u64 segment_handle;
} vl_api_application_attach_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_app_attach {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 options[16];
    u8 namespace_id_len;
    u8 namespace_id[64];
} vl_api_app_attach_t;
typedef struct __attribute__ ((packed)) _vl_api_app_attach_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 app_mq;
    u64 vpp_ctrl_mq;
    u8 vpp_ctrl_mq_thread;
    u32 app_index;
    u8 n_fds;
    u8 fd_flags;
    u32 segment_size;
    u8 segment_name_length;
    u8 segment_name[128];
    u64 segment_handle;
} vl_api_app_attach_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_app_add_cert_key_pair {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u16 cert_len;
    u16 certkey_len;
    u8 certkey[0];
} vl_api_app_add_cert_key_pair_t;
typedef struct __attribute__ ((packed)) _vl_api_app_add_cert_key_pair_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 index;
} vl_api_app_add_cert_key_pair_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_app_del_cert_key_pair {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 index;
} vl_api_app_del_cert_key_pair_t;
typedef struct __attribute__ ((packed)) _vl_api_app_del_cert_key_pair_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_app_del_cert_key_pair_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_application_tls_cert_add {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 app_index;
    u16 cert_len;
    u8 cert[0];
} vl_api_application_tls_cert_add_t;
typedef struct __attribute__ ((packed)) _vl_api_application_tls_cert_add_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_application_tls_cert_add_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_application_tls_key_add {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 app_index;
    u16 key_len;
    u8 key[0];
} vl_api_application_tls_key_add_t;
typedef struct __attribute__ ((packed)) _vl_api_application_tls_key_add_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_application_tls_key_add_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_application_detach {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_application_detach_t;
typedef struct __attribute__ ((packed)) _vl_api_application_detach_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_application_detach_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_map_another_segment {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 fd_flags;
    u32 segment_size;
    u8 segment_name[128];
    u64 segment_handle;
} vl_api_map_another_segment_t;
typedef struct __attribute__ ((packed)) _vl_api_map_another_segment_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_map_another_segment_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_unmap_segment {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 segment_handle;
} vl_api_unmap_segment_t;
typedef struct __attribute__ ((packed)) _vl_api_unmap_segment_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_unmap_segment_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bind_uri {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 accept_cookie;
    u8 uri[128];
} vl_api_bind_uri_t;
typedef struct __attribute__ ((packed)) _vl_api_bind_uri_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_bind_uri_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_unbind_uri {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 uri[128];
} vl_api_unbind_uri_t;
typedef struct __attribute__ ((packed)) _vl_api_unbind_uri_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_unbind_uri_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_connect_uri {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 client_queue_address;
    u64 options[16];
    u8 uri[128];
} vl_api_connect_uri_t;
typedef struct __attribute__ ((packed)) _vl_api_connect_uri_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_connect_uri_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_disconnect_session {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 handle;
} vl_api_disconnect_session_t;
typedef struct __attribute__ ((packed)) _vl_api_disconnect_session_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 handle;
} vl_api_disconnect_session_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bind_sock {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 wrk_index;
    u32 vrf;
    u8 is_ip4;
    u8 ip[16];
    u16 port;
    u8 proto;
    u64 options[16];
} vl_api_bind_sock_t;
typedef struct __attribute__ ((packed)) _vl_api_bind_sock_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_bind_sock_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_unbind_sock {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 wrk_index;
    u64 handle;
} vl_api_unbind_sock_t;
typedef struct __attribute__ ((packed)) _vl_api_unbind_sock_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_unbind_sock_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_connect_sock {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 wrk_index;
    u64 client_queue_address;
    u64 options[16];
    u32 vrf;
    u8 is_ip4;
    u8 ip[16];
    u16 port;
    u8 proto;
    u64 parent_handle;
    u8 hostname_len;
    u8 hostname[0];
} vl_api_connect_sock_t;
typedef struct __attribute__ ((packed)) _vl_api_connect_sock_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_connect_sock_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_app_cut_through_registration_add {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 evt_q_address;
    u64 peer_evt_q_address;
    u32 wrk_index;
    u8 n_fds;
    u8 fd_flags;
} vl_api_app_cut_through_registration_add_t;
typedef struct __attribute__ ((packed)) _vl_api_app_cut_through_registration_add_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_app_cut_through_registration_add_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_app_worker_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 app_index;
    u32 wrk_index;
    u8 is_add;
} vl_api_app_worker_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_app_worker_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 wrk_index;
    u64 app_event_queue_address;
    u8 n_fds;
    u8 fd_flags;
    u8 segment_name_length;
    u8 segment_name[128];
    u64 segment_handle;
    u8 is_add;
} vl_api_app_worker_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_session_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enable;
} vl_api_session_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_session_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_session_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_app_namespace_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 secret;
    u32 sw_if_index;
    u32 ip4_fib_id;
    u32 ip6_fib_id;
    u8 namespace_id_len;
    u8 namespace_id[64];
} vl_api_app_namespace_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_app_namespace_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 appns_index;
} vl_api_app_namespace_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_session_rule_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 transport_proto;
    u8 is_ip4;
    u8 lcl_ip[16];
    u8 lcl_plen;
    u8 rmt_ip[16];
    u8 rmt_plen;
    u16 lcl_port;
    u16 rmt_port;
    u32 action_index;
    u8 is_add;
    u32 appns_index;
    u8 scope;
    u8 tag[64];
} vl_api_session_rule_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_session_rule_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_session_rule_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_session_rules_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_session_rules_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_session_rules_details {
    u16 _vl_msg_id;
    u32 context;
    u8 transport_proto;
    u8 is_ip4;
    u8 lcl_ip[16];
    u8 lcl_plen;
    u8 rmt_ip[16];
    u8 rmt_plen;
    u16 lcl_port;
    u16 rmt_port;
    u32 action_index;
    u32 appns_index;
    u8 scope;
    u8 tag[64];
} vl_api_session_rules_details_t;

#endif

/*
 * VLIB API definitions 2021-09-27 00:01:44
 * Input file: session.api
 * Automatically generated: please edit the input file NOT this file!
 */

#include <stdbool.h>
#if defined(vl_msg_id)||defined(vl_union_id) \
    || defined(vl_printfun) ||defined(vl_endianfun) \
    || defined(vl_api_version)||defined(vl_typedefs) \
    || defined(vl_msg_name)||defined(vl_msg_name_crc_list) \
    || defined(vl_api_version_tuple)
/* ok, something was selected */
#else
#warning no content included from session.api
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))
/* Imported API files */
#ifndef vl_api_version
#endif

/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_APPLICATION_ATTACH, vl_api_application_attach_t_handler)
vl_msg_id(VL_API_APPLICATION_ATTACH_REPLY, vl_api_application_attach_reply_t_handler)
vl_msg_id(VL_API_APP_ATTACH, vl_api_app_attach_t_handler)
vl_msg_id(VL_API_APP_ATTACH_REPLY, vl_api_app_attach_reply_t_handler)
vl_msg_id(VL_API_APP_ADD_CERT_KEY_PAIR, vl_api_app_add_cert_key_pair_t_handler)
vl_msg_id(VL_API_APP_ADD_CERT_KEY_PAIR_REPLY, vl_api_app_add_cert_key_pair_reply_t_handler)
vl_msg_id(VL_API_APP_DEL_CERT_KEY_PAIR, vl_api_app_del_cert_key_pair_t_handler)
vl_msg_id(VL_API_APP_DEL_CERT_KEY_PAIR_REPLY, vl_api_app_del_cert_key_pair_reply_t_handler)
vl_msg_id(VL_API_APPLICATION_TLS_CERT_ADD, vl_api_application_tls_cert_add_t_handler)
vl_msg_id(VL_API_APPLICATION_TLS_CERT_ADD_REPLY, vl_api_application_tls_cert_add_reply_t_handler)
vl_msg_id(VL_API_APPLICATION_TLS_KEY_ADD, vl_api_application_tls_key_add_t_handler)
vl_msg_id(VL_API_APPLICATION_TLS_KEY_ADD_REPLY, vl_api_application_tls_key_add_reply_t_handler)
vl_msg_id(VL_API_APPLICATION_DETACH, vl_api_application_detach_t_handler)
vl_msg_id(VL_API_APPLICATION_DETACH_REPLY, vl_api_application_detach_reply_t_handler)
vl_msg_id(VL_API_MAP_ANOTHER_SEGMENT, vl_api_map_another_segment_t_handler)
vl_msg_id(VL_API_MAP_ANOTHER_SEGMENT_REPLY, vl_api_map_another_segment_reply_t_handler)
vl_msg_id(VL_API_UNMAP_SEGMENT, vl_api_unmap_segment_t_handler)
vl_msg_id(VL_API_UNMAP_SEGMENT_REPLY, vl_api_unmap_segment_reply_t_handler)
vl_msg_id(VL_API_BIND_URI, vl_api_bind_uri_t_handler)
vl_msg_id(VL_API_BIND_URI_REPLY, vl_api_bind_uri_reply_t_handler)
vl_msg_id(VL_API_UNBIND_URI, vl_api_unbind_uri_t_handler)
vl_msg_id(VL_API_UNBIND_URI_REPLY, vl_api_unbind_uri_reply_t_handler)
vl_msg_id(VL_API_CONNECT_URI, vl_api_connect_uri_t_handler)
vl_msg_id(VL_API_CONNECT_URI_REPLY, vl_api_connect_uri_reply_t_handler)
vl_msg_id(VL_API_DISCONNECT_SESSION, vl_api_disconnect_session_t_handler)
vl_msg_id(VL_API_DISCONNECT_SESSION_REPLY, vl_api_disconnect_session_reply_t_handler)
vl_msg_id(VL_API_BIND_SOCK, vl_api_bind_sock_t_handler)
vl_msg_id(VL_API_BIND_SOCK_REPLY, vl_api_bind_sock_reply_t_handler)
vl_msg_id(VL_API_UNBIND_SOCK, vl_api_unbind_sock_t_handler)
vl_msg_id(VL_API_UNBIND_SOCK_REPLY, vl_api_unbind_sock_reply_t_handler)
vl_msg_id(VL_API_CONNECT_SOCK, vl_api_connect_sock_t_handler)
vl_msg_id(VL_API_CONNECT_SOCK_REPLY, vl_api_connect_sock_reply_t_handler)
vl_msg_id(VL_API_APP_CUT_THROUGH_REGISTRATION_ADD, vl_api_app_cut_through_registration_add_t_handler)
vl_msg_id(VL_API_APP_CUT_THROUGH_REGISTRATION_ADD_REPLY, vl_api_app_cut_through_registration_add_reply_t_handler)
vl_msg_id(VL_API_APP_WORKER_ADD_DEL, vl_api_app_worker_add_del_t_handler)
vl_msg_id(VL_API_APP_WORKER_ADD_DEL_REPLY, vl_api_app_worker_add_del_reply_t_handler)
vl_msg_id(VL_API_SESSION_ENABLE_DISABLE, vl_api_session_enable_disable_t_handler)
vl_msg_id(VL_API_SESSION_ENABLE_DISABLE_REPLY, vl_api_session_enable_disable_reply_t_handler)
vl_msg_id(VL_API_APP_NAMESPACE_ADD_DEL, vl_api_app_namespace_add_del_t_handler)
vl_msg_id(VL_API_APP_NAMESPACE_ADD_DEL_REPLY, vl_api_app_namespace_add_del_reply_t_handler)
vl_msg_id(VL_API_SESSION_RULE_ADD_DEL, vl_api_session_rule_add_del_t_handler)
vl_msg_id(VL_API_SESSION_RULE_ADD_DEL_REPLY, vl_api_session_rule_add_del_reply_t_handler)
vl_msg_id(VL_API_SESSION_RULES_DUMP, vl_api_session_rules_dump_t_handler)
vl_msg_id(VL_API_SESSION_RULES_DETAILS, vl_api_session_rules_details_t_handler)
#endif
/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_application_attach_t, 1)
vl_msg_name(vl_api_application_attach_reply_t, 1)
vl_msg_name(vl_api_app_attach_t, 1)
vl_msg_name(vl_api_app_attach_reply_t, 1)
vl_msg_name(vl_api_app_add_cert_key_pair_t, 1)
vl_msg_name(vl_api_app_add_cert_key_pair_reply_t, 1)
vl_msg_name(vl_api_app_del_cert_key_pair_t, 1)
vl_msg_name(vl_api_app_del_cert_key_pair_reply_t, 1)
vl_msg_name(vl_api_application_tls_cert_add_t, 1)
vl_msg_name(vl_api_application_tls_cert_add_reply_t, 1)
vl_msg_name(vl_api_application_tls_key_add_t, 1)
vl_msg_name(vl_api_application_tls_key_add_reply_t, 1)
vl_msg_name(vl_api_application_detach_t, 1)
vl_msg_name(vl_api_application_detach_reply_t, 1)
vl_msg_name(vl_api_map_another_segment_t, 1)
vl_msg_name(vl_api_map_another_segment_reply_t, 1)
vl_msg_name(vl_api_unmap_segment_t, 1)
vl_msg_name(vl_api_unmap_segment_reply_t, 1)
vl_msg_name(vl_api_bind_uri_t, 1)
vl_msg_name(vl_api_bind_uri_reply_t, 1)
vl_msg_name(vl_api_unbind_uri_t, 1)
vl_msg_name(vl_api_unbind_uri_reply_t, 1)
vl_msg_name(vl_api_connect_uri_t, 1)
vl_msg_name(vl_api_connect_uri_reply_t, 1)
vl_msg_name(vl_api_disconnect_session_t, 1)
vl_msg_name(vl_api_disconnect_session_reply_t, 1)
vl_msg_name(vl_api_bind_sock_t, 1)
vl_msg_name(vl_api_bind_sock_reply_t, 1)
vl_msg_name(vl_api_unbind_sock_t, 1)
vl_msg_name(vl_api_unbind_sock_reply_t, 1)
vl_msg_name(vl_api_connect_sock_t, 1)
vl_msg_name(vl_api_connect_sock_reply_t, 1)
vl_msg_name(vl_api_app_cut_through_registration_add_t, 1)
vl_msg_name(vl_api_app_cut_through_registration_add_reply_t, 1)
vl_msg_name(vl_api_app_worker_add_del_t, 1)
vl_msg_name(vl_api_app_worker_add_del_reply_t, 1)
vl_msg_name(vl_api_session_enable_disable_t, 1)
vl_msg_name(vl_api_session_enable_disable_reply_t, 1)
vl_msg_name(vl_api_app_namespace_add_del_t, 1)
vl_msg_name(vl_api_app_namespace_add_del_reply_t, 1)
vl_msg_name(vl_api_session_rule_add_del_t, 1)
vl_msg_name(vl_api_session_rule_add_del_reply_t, 1)
vl_msg_name(vl_api_session_rules_dump_t, 1)
vl_msg_name(vl_api_session_rules_details_t, 1)
#endif
/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_session \
_(VL_API_APPLICATION_ATTACH, application_attach, 81d4f974) \
_(VL_API_APPLICATION_ATTACH_REPLY, application_attach_reply, 581866e8) \
_(VL_API_APP_ATTACH, app_attach, ed08f4bd) \
_(VL_API_APP_ATTACH_REPLY, app_attach_reply, 0112f647) \
_(VL_API_APP_ADD_CERT_KEY_PAIR, app_add_cert_key_pair, 02eb8016) \
_(VL_API_APP_ADD_CERT_KEY_PAIR_REPLY, app_add_cert_key_pair_reply, b42958d0) \
_(VL_API_APP_DEL_CERT_KEY_PAIR, app_del_cert_key_pair, 8ac76db6) \
_(VL_API_APP_DEL_CERT_KEY_PAIR_REPLY, app_del_cert_key_pair_reply, e8d4e804) \
_(VL_API_APPLICATION_TLS_CERT_ADD, application_tls_cert_add, 3f5cfe45) \
_(VL_API_APPLICATION_TLS_CERT_ADD_REPLY, application_tls_cert_add_reply, e8d4e804) \
_(VL_API_APPLICATION_TLS_KEY_ADD, application_tls_key_add, 5eaf70cd) \
_(VL_API_APPLICATION_TLS_KEY_ADD_REPLY, application_tls_key_add_reply, e8d4e804) \
_(VL_API_APPLICATION_DETACH, application_detach, 51077d14) \
_(VL_API_APPLICATION_DETACH_REPLY, application_detach_reply, e8d4e804) \
_(VL_API_MAP_ANOTHER_SEGMENT, map_another_segment, dc2d630b) \
_(VL_API_MAP_ANOTHER_SEGMENT_REPLY, map_another_segment_reply, e8d4e804) \
_(VL_API_UNMAP_SEGMENT, unmap_segment, f77096f6) \
_(VL_API_UNMAP_SEGMENT_REPLY, unmap_segment_reply, e8d4e804) \
_(VL_API_BIND_URI, bind_uri, fae140cb) \
_(VL_API_BIND_URI_REPLY, bind_uri_reply, e8d4e804) \
_(VL_API_UNBIND_URI, unbind_uri, 294cf07d) \
_(VL_API_UNBIND_URI_REPLY, unbind_uri_reply, e8d4e804) \
_(VL_API_CONNECT_URI, connect_uri, a36143d6) \
_(VL_API_CONNECT_URI_REPLY, connect_uri_reply, e8d4e804) \
_(VL_API_DISCONNECT_SESSION, disconnect_session, 7279205b) \
_(VL_API_DISCONNECT_SESSION_REPLY, disconnect_session_reply, d6960a03) \
_(VL_API_BIND_SOCK, bind_sock, 0394633f) \
_(VL_API_BIND_SOCK_REPLY, bind_sock_reply, e8d4e804) \
_(VL_API_UNBIND_SOCK, unbind_sock, 08880908) \
_(VL_API_UNBIND_SOCK_REPLY, unbind_sock_reply, e8d4e804) \
_(VL_API_CONNECT_SOCK, connect_sock, d2b460ca) \
_(VL_API_CONNECT_SOCK_REPLY, connect_sock_reply, e8d4e804) \
_(VL_API_APP_CUT_THROUGH_REGISTRATION_ADD, app_cut_through_registration_add, 6d73b1b9) \
_(VL_API_APP_CUT_THROUGH_REGISTRATION_ADD_REPLY, app_cut_through_registration_add_reply, e8d4e804) \
_(VL_API_APP_WORKER_ADD_DEL, app_worker_add_del, 6d2b2279) \
_(VL_API_APP_WORKER_ADD_DEL_REPLY, app_worker_add_del_reply, 56b21abc) \
_(VL_API_SESSION_ENABLE_DISABLE, session_enable_disable, 30ac9be7) \
_(VL_API_SESSION_ENABLE_DISABLE_REPLY, session_enable_disable_reply, e8d4e804) \
_(VL_API_APP_NAMESPACE_ADD_DEL, app_namespace_add_del, dd074c65) \
_(VL_API_APP_NAMESPACE_ADD_DEL_REPLY, app_namespace_add_del_reply, 85137120) \
_(VL_API_SESSION_RULE_ADD_DEL, session_rule_add_del, 4ab2eb06) \
_(VL_API_SESSION_RULE_ADD_DEL_REPLY, session_rule_add_del_reply, e8d4e804) \
_(VL_API_SESSION_RULES_DUMP, session_rules_dump, 51077d14) \
_(VL_API_SESSION_RULES_DETAILS, session_rules_details, a52b0e96) 
#endif
/****** Typedefs ******/

#ifdef vl_typedefs
#include "session.api_types.h"
#endif
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_session_printfun_types
#define included_session_printfun_types


#endif
#endif /* vl_printfun_types */
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_session_printfun
#define included_session_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_application_attach_t_print (vl_api_application_attach_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_application_attach_t: */
    s = format(s, "vl_api_application_attach_t:");
    s = format(s, "\n%Uinitial_segment_size: %u", format_white_space, indent, a->initial_segment_size);
    for (i = 0; i < 16; i++) {
        s = format(s, "\n%Uoptions: %llu",
                   format_white_space, indent, a->options[i]);
    }
    s = format(s, "\n%Unamespace_id_len: %u", format_white_space, indent, a->namespace_id_len);
    s = format(s, "\n%Unamespace_id: %U", format_white_space, indent, format_hex_bytes, a, 64);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_application_attach_reply_t_print (vl_api_application_attach_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_application_attach_reply_t: */
    s = format(s, "vl_api_application_attach_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Uapp_event_queue_address: %llu", format_white_space, indent, a->app_event_queue_address);
    s = format(s, "\n%Un_fds: %u", format_white_space, indent, a->n_fds);
    s = format(s, "\n%Ufd_flags: %u", format_white_space, indent, a->fd_flags);
    s = format(s, "\n%Usegment_size: %u", format_white_space, indent, a->segment_size);
    s = format(s, "\n%Usegment_name_length: %u", format_white_space, indent, a->segment_name_length);
    s = format(s, "\n%Usegment_name: %U", format_white_space, indent, format_hex_bytes, a, 128);
    s = format(s, "\n%Uapp_index: %u", format_white_space, indent, a->app_index);
    s = format(s, "\n%Usegment_handle: %llu", format_white_space, indent, a->segment_handle);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_attach_t_print (vl_api_app_attach_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_attach_t: */
    s = format(s, "vl_api_app_attach_t:");
    for (i = 0; i < 16; i++) {
        s = format(s, "\n%Uoptions: %llu",
                   format_white_space, indent, a->options[i]);
    }
    s = format(s, "\n%Unamespace_id_len: %u", format_white_space, indent, a->namespace_id_len);
    s = format(s, "\n%Unamespace_id: %U", format_white_space, indent, format_hex_bytes, a, 64);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_attach_reply_t_print (vl_api_app_attach_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_attach_reply_t: */
    s = format(s, "vl_api_app_attach_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Uapp_mq: %llu", format_white_space, indent, a->app_mq);
    s = format(s, "\n%Uvpp_ctrl_mq: %llu", format_white_space, indent, a->vpp_ctrl_mq);
    s = format(s, "\n%Uvpp_ctrl_mq_thread: %u", format_white_space, indent, a->vpp_ctrl_mq_thread);
    s = format(s, "\n%Uapp_index: %u", format_white_space, indent, a->app_index);
    s = format(s, "\n%Un_fds: %u", format_white_space, indent, a->n_fds);
    s = format(s, "\n%Ufd_flags: %u", format_white_space, indent, a->fd_flags);
    s = format(s, "\n%Usegment_size: %u", format_white_space, indent, a->segment_size);
    s = format(s, "\n%Usegment_name_length: %u", format_white_space, indent, a->segment_name_length);
    s = format(s, "\n%Usegment_name: %U", format_white_space, indent, format_hex_bytes, a, 128);
    s = format(s, "\n%Usegment_handle: %llu", format_white_space, indent, a->segment_handle);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_add_cert_key_pair_t_print (vl_api_app_add_cert_key_pair_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_add_cert_key_pair_t: */
    s = format(s, "vl_api_app_add_cert_key_pair_t:");
    s = format(s, "\n%Ucert_len: %u", format_white_space, indent, a->cert_len);
    s = format(s, "\n%Ucertkey_len: %u", format_white_space, indent, a->certkey_len);
    s = format(s, "\n%Ucertkey: %U", format_white_space, indent, format_hex_bytes, a->certkey, a->certkey_len);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_add_cert_key_pair_reply_t_print (vl_api_app_add_cert_key_pair_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_add_cert_key_pair_reply_t: */
    s = format(s, "vl_api_app_add_cert_key_pair_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Uindex: %u", format_white_space, indent, a->index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_del_cert_key_pair_t_print (vl_api_app_del_cert_key_pair_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_del_cert_key_pair_t: */
    s = format(s, "vl_api_app_del_cert_key_pair_t:");
    s = format(s, "\n%Uindex: %u", format_white_space, indent, a->index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_del_cert_key_pair_reply_t_print (vl_api_app_del_cert_key_pair_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_del_cert_key_pair_reply_t: */
    s = format(s, "vl_api_app_del_cert_key_pair_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_application_tls_cert_add_t_print (vl_api_application_tls_cert_add_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_application_tls_cert_add_t: */
    s = format(s, "vl_api_application_tls_cert_add_t:");
    s = format(s, "\n%Uapp_index: %u", format_white_space, indent, a->app_index);
    s = format(s, "\n%Ucert_len: %u", format_white_space, indent, a->cert_len);
    s = format(s, "\n%Ucert: %U", format_white_space, indent, format_hex_bytes, a->cert, a->cert_len);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_application_tls_cert_add_reply_t_print (vl_api_application_tls_cert_add_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_application_tls_cert_add_reply_t: */
    s = format(s, "vl_api_application_tls_cert_add_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_application_tls_key_add_t_print (vl_api_application_tls_key_add_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_application_tls_key_add_t: */
    s = format(s, "vl_api_application_tls_key_add_t:");
    s = format(s, "\n%Uapp_index: %u", format_white_space, indent, a->app_index);
    s = format(s, "\n%Ukey_len: %u", format_white_space, indent, a->key_len);
    s = format(s, "\n%Ukey: %U", format_white_space, indent, format_hex_bytes, a->key, a->key_len);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_application_tls_key_add_reply_t_print (vl_api_application_tls_key_add_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_application_tls_key_add_reply_t: */
    s = format(s, "vl_api_application_tls_key_add_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_application_detach_t_print (vl_api_application_detach_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_application_detach_t: */
    s = format(s, "vl_api_application_detach_t:");
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_application_detach_reply_t_print (vl_api_application_detach_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_application_detach_reply_t: */
    s = format(s, "vl_api_application_detach_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_map_another_segment_t_print (vl_api_map_another_segment_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_map_another_segment_t: */
    s = format(s, "vl_api_map_another_segment_t:");
    s = format(s, "\n%Ufd_flags: %u", format_white_space, indent, a->fd_flags);
    s = format(s, "\n%Usegment_size: %u", format_white_space, indent, a->segment_size);
    s = format(s, "\n%Usegment_name: %U", format_white_space, indent, format_hex_bytes, a, 128);
    s = format(s, "\n%Usegment_handle: %llu", format_white_space, indent, a->segment_handle);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_map_another_segment_reply_t_print (vl_api_map_another_segment_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_map_another_segment_reply_t: */
    s = format(s, "vl_api_map_another_segment_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_unmap_segment_t_print (vl_api_unmap_segment_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_unmap_segment_t: */
    s = format(s, "vl_api_unmap_segment_t:");
    s = format(s, "\n%Usegment_handle: %llu", format_white_space, indent, a->segment_handle);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_unmap_segment_reply_t_print (vl_api_unmap_segment_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_unmap_segment_reply_t: */
    s = format(s, "vl_api_unmap_segment_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_bind_uri_t_print (vl_api_bind_uri_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_bind_uri_t: */
    s = format(s, "vl_api_bind_uri_t:");
    s = format(s, "\n%Uaccept_cookie: %u", format_white_space, indent, a->accept_cookie);
    s = format(s, "\n%Uuri: %U", format_white_space, indent, format_hex_bytes, a, 128);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_bind_uri_reply_t_print (vl_api_bind_uri_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_bind_uri_reply_t: */
    s = format(s, "vl_api_bind_uri_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_unbind_uri_t_print (vl_api_unbind_uri_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_unbind_uri_t: */
    s = format(s, "vl_api_unbind_uri_t:");
    s = format(s, "\n%Uuri: %U", format_white_space, indent, format_hex_bytes, a, 128);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_unbind_uri_reply_t_print (vl_api_unbind_uri_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_unbind_uri_reply_t: */
    s = format(s, "vl_api_unbind_uri_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_connect_uri_t_print (vl_api_connect_uri_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_connect_uri_t: */
    s = format(s, "vl_api_connect_uri_t:");
    s = format(s, "\n%Uclient_queue_address: %llu", format_white_space, indent, a->client_queue_address);
    for (i = 0; i < 16; i++) {
        s = format(s, "\n%Uoptions: %llu",
                   format_white_space, indent, a->options[i]);
    }
    s = format(s, "\n%Uuri: %U", format_white_space, indent, format_hex_bytes, a, 128);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_connect_uri_reply_t_print (vl_api_connect_uri_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_connect_uri_reply_t: */
    s = format(s, "vl_api_connect_uri_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_disconnect_session_t_print (vl_api_disconnect_session_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_disconnect_session_t: */
    s = format(s, "vl_api_disconnect_session_t:");
    s = format(s, "\n%Uhandle: %llu", format_white_space, indent, a->handle);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_disconnect_session_reply_t_print (vl_api_disconnect_session_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_disconnect_session_reply_t: */
    s = format(s, "vl_api_disconnect_session_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Uhandle: %llu", format_white_space, indent, a->handle);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_bind_sock_t_print (vl_api_bind_sock_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_bind_sock_t: */
    s = format(s, "vl_api_bind_sock_t:");
    s = format(s, "\n%Uwrk_index: %u", format_white_space, indent, a->wrk_index);
    s = format(s, "\n%Uvrf: %u", format_white_space, indent, a->vrf);
    s = format(s, "\n%Uis_ip4: %u", format_white_space, indent, a->is_ip4);
    s = format(s, "\n%Uip: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Uport: %u", format_white_space, indent, a->port);
    s = format(s, "\n%Uproto: %u", format_white_space, indent, a->proto);
    for (i = 0; i < 16; i++) {
        s = format(s, "\n%Uoptions: %llu",
                   format_white_space, indent, a->options[i]);
    }
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_bind_sock_reply_t_print (vl_api_bind_sock_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_bind_sock_reply_t: */
    s = format(s, "vl_api_bind_sock_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_unbind_sock_t_print (vl_api_unbind_sock_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_unbind_sock_t: */
    s = format(s, "vl_api_unbind_sock_t:");
    s = format(s, "\n%Uwrk_index: %u", format_white_space, indent, a->wrk_index);
    s = format(s, "\n%Uhandle: %llu", format_white_space, indent, a->handle);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_unbind_sock_reply_t_print (vl_api_unbind_sock_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_unbind_sock_reply_t: */
    s = format(s, "vl_api_unbind_sock_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_connect_sock_t_print (vl_api_connect_sock_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_connect_sock_t: */
    s = format(s, "vl_api_connect_sock_t:");
    s = format(s, "\n%Uwrk_index: %u", format_white_space, indent, a->wrk_index);
    s = format(s, "\n%Uclient_queue_address: %llu", format_white_space, indent, a->client_queue_address);
    for (i = 0; i < 16; i++) {
        s = format(s, "\n%Uoptions: %llu",
                   format_white_space, indent, a->options[i]);
    }
    s = format(s, "\n%Uvrf: %u", format_white_space, indent, a->vrf);
    s = format(s, "\n%Uis_ip4: %u", format_white_space, indent, a->is_ip4);
    s = format(s, "\n%Uip: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Uport: %u", format_white_space, indent, a->port);
    s = format(s, "\n%Uproto: %u", format_white_space, indent, a->proto);
    s = format(s, "\n%Uparent_handle: %llu", format_white_space, indent, a->parent_handle);
    s = format(s, "\n%Uhostname_len: %u", format_white_space, indent, a->hostname_len);
    s = format(s, "\n%Uhostname: %U", format_white_space, indent, format_hex_bytes, a->hostname, a->hostname_len);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_connect_sock_reply_t_print (vl_api_connect_sock_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_connect_sock_reply_t: */
    s = format(s, "vl_api_connect_sock_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_cut_through_registration_add_t_print (vl_api_app_cut_through_registration_add_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_cut_through_registration_add_t: */
    s = format(s, "vl_api_app_cut_through_registration_add_t:");
    s = format(s, "\n%Uevt_q_address: %llu", format_white_space, indent, a->evt_q_address);
    s = format(s, "\n%Upeer_evt_q_address: %llu", format_white_space, indent, a->peer_evt_q_address);
    s = format(s, "\n%Uwrk_index: %u", format_white_space, indent, a->wrk_index);
    s = format(s, "\n%Un_fds: %u", format_white_space, indent, a->n_fds);
    s = format(s, "\n%Ufd_flags: %u", format_white_space, indent, a->fd_flags);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_cut_through_registration_add_reply_t_print (vl_api_app_cut_through_registration_add_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_cut_through_registration_add_reply_t: */
    s = format(s, "vl_api_app_cut_through_registration_add_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_worker_add_del_t_print (vl_api_app_worker_add_del_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_worker_add_del_t: */
    s = format(s, "vl_api_app_worker_add_del_t:");
    s = format(s, "\n%Uapp_index: %u", format_white_space, indent, a->app_index);
    s = format(s, "\n%Uwrk_index: %u", format_white_space, indent, a->wrk_index);
    s = format(s, "\n%Uis_add: %u", format_white_space, indent, a->is_add);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_worker_add_del_reply_t_print (vl_api_app_worker_add_del_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_worker_add_del_reply_t: */
    s = format(s, "vl_api_app_worker_add_del_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Uwrk_index: %u", format_white_space, indent, a->wrk_index);
    s = format(s, "\n%Uapp_event_queue_address: %llu", format_white_space, indent, a->app_event_queue_address);
    s = format(s, "\n%Un_fds: %u", format_white_space, indent, a->n_fds);
    s = format(s, "\n%Ufd_flags: %u", format_white_space, indent, a->fd_flags);
    s = format(s, "\n%Usegment_name_length: %u", format_white_space, indent, a->segment_name_length);
    s = format(s, "\n%Usegment_name: %U", format_white_space, indent, format_hex_bytes, a, 128);
    s = format(s, "\n%Usegment_handle: %llu", format_white_space, indent, a->segment_handle);
    s = format(s, "\n%Uis_add: %u", format_white_space, indent, a->is_add);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_session_enable_disable_t_print (vl_api_session_enable_disable_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_session_enable_disable_t: */
    s = format(s, "vl_api_session_enable_disable_t:");
    s = format(s, "\n%Uis_enable: %u", format_white_space, indent, a->is_enable);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_session_enable_disable_reply_t_print (vl_api_session_enable_disable_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_session_enable_disable_reply_t: */
    s = format(s, "vl_api_session_enable_disable_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_namespace_add_del_t_print (vl_api_app_namespace_add_del_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_namespace_add_del_t: */
    s = format(s, "vl_api_app_namespace_add_del_t:");
    s = format(s, "\n%Usecret: %llu", format_white_space, indent, a->secret);
    s = format(s, "\n%Usw_if_index: %u", format_white_space, indent, a->sw_if_index);
    s = format(s, "\n%Uip4_fib_id: %u", format_white_space, indent, a->ip4_fib_id);
    s = format(s, "\n%Uip6_fib_id: %u", format_white_space, indent, a->ip6_fib_id);
    s = format(s, "\n%Unamespace_id_len: %u", format_white_space, indent, a->namespace_id_len);
    s = format(s, "\n%Unamespace_id: %U", format_white_space, indent, format_hex_bytes, a, 64);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_app_namespace_add_del_reply_t_print (vl_api_app_namespace_add_del_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_app_namespace_add_del_reply_t: */
    s = format(s, "vl_api_app_namespace_add_del_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Uappns_index: %u", format_white_space, indent, a->appns_index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_session_rule_add_del_t_print (vl_api_session_rule_add_del_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_session_rule_add_del_t: */
    s = format(s, "vl_api_session_rule_add_del_t:");
    s = format(s, "\n%Utransport_proto: %u", format_white_space, indent, a->transport_proto);
    s = format(s, "\n%Uis_ip4: %u", format_white_space, indent, a->is_ip4);
    s = format(s, "\n%Ulcl_ip: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Ulcl_plen: %u", format_white_space, indent, a->lcl_plen);
    s = format(s, "\n%Urmt_ip: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Urmt_plen: %u", format_white_space, indent, a->rmt_plen);
    s = format(s, "\n%Ulcl_port: %u", format_white_space, indent, a->lcl_port);
    s = format(s, "\n%Urmt_port: %u", format_white_space, indent, a->rmt_port);
    s = format(s, "\n%Uaction_index: %u", format_white_space, indent, a->action_index);
    s = format(s, "\n%Uis_add: %u", format_white_space, indent, a->is_add);
    s = format(s, "\n%Uappns_index: %u", format_white_space, indent, a->appns_index);
    s = format(s, "\n%Uscope: %u", format_white_space, indent, a->scope);
    s = format(s, "\n%Utag: %U", format_white_space, indent, format_hex_bytes, a, 64);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_session_rule_add_del_reply_t_print (vl_api_session_rule_add_del_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_session_rule_add_del_reply_t: */
    s = format(s, "vl_api_session_rule_add_del_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_session_rules_dump_t_print (vl_api_session_rules_dump_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_session_rules_dump_t: */
    s = format(s, "vl_api_session_rules_dump_t:");
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_session_rules_details_t_print (vl_api_session_rules_details_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_session_rules_details_t: */
    s = format(s, "vl_api_session_rules_details_t:");
    s = format(s, "\n%Utransport_proto: %u", format_white_space, indent, a->transport_proto);
    s = format(s, "\n%Uis_ip4: %u", format_white_space, indent, a->is_ip4);
    s = format(s, "\n%Ulcl_ip: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Ulcl_plen: %u", format_white_space, indent, a->lcl_plen);
    s = format(s, "\n%Urmt_ip: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Urmt_plen: %u", format_white_space, indent, a->rmt_plen);
    s = format(s, "\n%Ulcl_port: %u", format_white_space, indent, a->lcl_port);
    s = format(s, "\n%Urmt_port: %u", format_white_space, indent, a->rmt_port);
    s = format(s, "\n%Uaction_index: %u", format_white_space, indent, a->action_index);
    s = format(s, "\n%Uappns_index: %u", format_white_space, indent, a->appns_index);
    s = format(s, "\n%Uscope: %u", format_white_space, indent, a->scope);
    s = format(s, "\n%Utag: %U", format_white_space, indent, format_hex_bytes, a, 64);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}


#endif
#endif /* vl_printfun */

/****** Endian swap functions *****/
#ifdef vl_endianfun
#ifndef included_session_endianfun
#define included_session_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_application_attach_t_endian (vl_api_application_attach_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->initial_segment_size = clib_net_to_host_u32(a->initial_segment_size);
    for (i = 0; i < 16; i++) {
        a->options[i] = clib_net_to_host_u64(a->options[i]);
    }
    /* a->namespace_id_len = a->namespace_id_len (no-op) */
    /* a->namespace_id = a->namespace_id (no-op) */
}

static inline void vl_api_application_attach_reply_t_endian (vl_api_application_attach_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->app_event_queue_address = clib_net_to_host_u64(a->app_event_queue_address);
    /* a->n_fds = a->n_fds (no-op) */
    /* a->fd_flags = a->fd_flags (no-op) */
    a->segment_size = clib_net_to_host_u32(a->segment_size);
    /* a->segment_name_length = a->segment_name_length (no-op) */
    /* a->segment_name = a->segment_name (no-op) */
    a->app_index = clib_net_to_host_u32(a->app_index);
    a->segment_handle = clib_net_to_host_u64(a->segment_handle);
}

static inline void vl_api_app_attach_t_endian (vl_api_app_attach_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    for (i = 0; i < 16; i++) {
        a->options[i] = clib_net_to_host_u64(a->options[i]);
    }
    /* a->namespace_id_len = a->namespace_id_len (no-op) */
    /* a->namespace_id = a->namespace_id (no-op) */
}

static inline void vl_api_app_attach_reply_t_endian (vl_api_app_attach_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->app_mq = clib_net_to_host_u64(a->app_mq);
    a->vpp_ctrl_mq = clib_net_to_host_u64(a->vpp_ctrl_mq);
    /* a->vpp_ctrl_mq_thread = a->vpp_ctrl_mq_thread (no-op) */
    a->app_index = clib_net_to_host_u32(a->app_index);
    /* a->n_fds = a->n_fds (no-op) */
    /* a->fd_flags = a->fd_flags (no-op) */
    a->segment_size = clib_net_to_host_u32(a->segment_size);
    /* a->segment_name_length = a->segment_name_length (no-op) */
    /* a->segment_name = a->segment_name (no-op) */
    a->segment_handle = clib_net_to_host_u64(a->segment_handle);
}

static inline void vl_api_app_add_cert_key_pair_t_endian (vl_api_app_add_cert_key_pair_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->cert_len = clib_net_to_host_u16(a->cert_len);
    a->certkey_len = clib_net_to_host_u16(a->certkey_len);
    /* a->certkey = a->certkey (no-op) */
}

static inline void vl_api_app_add_cert_key_pair_reply_t_endian (vl_api_app_add_cert_key_pair_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->index = clib_net_to_host_u32(a->index);
}

static inline void vl_api_app_del_cert_key_pair_t_endian (vl_api_app_del_cert_key_pair_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->index = clib_net_to_host_u32(a->index);
}

static inline void vl_api_app_del_cert_key_pair_reply_t_endian (vl_api_app_del_cert_key_pair_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_application_tls_cert_add_t_endian (vl_api_application_tls_cert_add_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->app_index = clib_net_to_host_u32(a->app_index);
    a->cert_len = clib_net_to_host_u16(a->cert_len);
    /* a->cert = a->cert (no-op) */
}

static inline void vl_api_application_tls_cert_add_reply_t_endian (vl_api_application_tls_cert_add_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_application_tls_key_add_t_endian (vl_api_application_tls_key_add_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->app_index = clib_net_to_host_u32(a->app_index);
    a->key_len = clib_net_to_host_u16(a->key_len);
    /* a->key = a->key (no-op) */
}

static inline void vl_api_application_tls_key_add_reply_t_endian (vl_api_application_tls_key_add_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_application_detach_t_endian (vl_api_application_detach_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_application_detach_reply_t_endian (vl_api_application_detach_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_map_another_segment_t_endian (vl_api_map_another_segment_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->fd_flags = a->fd_flags (no-op) */
    a->segment_size = clib_net_to_host_u32(a->segment_size);
    /* a->segment_name = a->segment_name (no-op) */
    a->segment_handle = clib_net_to_host_u64(a->segment_handle);
}

static inline void vl_api_map_another_segment_reply_t_endian (vl_api_map_another_segment_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_unmap_segment_t_endian (vl_api_unmap_segment_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->segment_handle = clib_net_to_host_u64(a->segment_handle);
}

static inline void vl_api_unmap_segment_reply_t_endian (vl_api_unmap_segment_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bind_uri_t_endian (vl_api_bind_uri_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->accept_cookie = clib_net_to_host_u32(a->accept_cookie);
    /* a->uri = a->uri (no-op) */
}

static inline void vl_api_bind_uri_reply_t_endian (vl_api_bind_uri_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_unbind_uri_t_endian (vl_api_unbind_uri_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->uri = a->uri (no-op) */
}

static inline void vl_api_unbind_uri_reply_t_endian (vl_api_unbind_uri_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_connect_uri_t_endian (vl_api_connect_uri_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->client_queue_address = clib_net_to_host_u64(a->client_queue_address);
    for (i = 0; i < 16; i++) {
        a->options[i] = clib_net_to_host_u64(a->options[i]);
    }
    /* a->uri = a->uri (no-op) */
}

static inline void vl_api_connect_uri_reply_t_endian (vl_api_connect_uri_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_disconnect_session_t_endian (vl_api_disconnect_session_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_disconnect_session_reply_t_endian (vl_api_disconnect_session_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_bind_sock_t_endian (vl_api_bind_sock_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->wrk_index = clib_net_to_host_u32(a->wrk_index);
    a->vrf = clib_net_to_host_u32(a->vrf);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->ip = a->ip (no-op) */
    a->port = clib_net_to_host_u16(a->port);
    /* a->proto = a->proto (no-op) */
    for (i = 0; i < 16; i++) {
        a->options[i] = clib_net_to_host_u64(a->options[i]);
    }
}

static inline void vl_api_bind_sock_reply_t_endian (vl_api_bind_sock_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_unbind_sock_t_endian (vl_api_unbind_sock_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->wrk_index = clib_net_to_host_u32(a->wrk_index);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_unbind_sock_reply_t_endian (vl_api_unbind_sock_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_connect_sock_t_endian (vl_api_connect_sock_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->wrk_index = clib_net_to_host_u32(a->wrk_index);
    a->client_queue_address = clib_net_to_host_u64(a->client_queue_address);
    for (i = 0; i < 16; i++) {
        a->options[i] = clib_net_to_host_u64(a->options[i]);
    }
    a->vrf = clib_net_to_host_u32(a->vrf);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->ip = a->ip (no-op) */
    a->port = clib_net_to_host_u16(a->port);
    /* a->proto = a->proto (no-op) */
    a->parent_handle = clib_net_to_host_u64(a->parent_handle);
    /* a->hostname_len = a->hostname_len (no-op) */
    /* a->hostname = a->hostname (no-op) */
}

static inline void vl_api_connect_sock_reply_t_endian (vl_api_connect_sock_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_app_cut_through_registration_add_t_endian (vl_api_app_cut_through_registration_add_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->evt_q_address = clib_net_to_host_u64(a->evt_q_address);
    a->peer_evt_q_address = clib_net_to_host_u64(a->peer_evt_q_address);
    a->wrk_index = clib_net_to_host_u32(a->wrk_index);
    /* a->n_fds = a->n_fds (no-op) */
    /* a->fd_flags = a->fd_flags (no-op) */
}

static inline void vl_api_app_cut_through_registration_add_reply_t_endian (vl_api_app_cut_through_registration_add_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_app_worker_add_del_t_endian (vl_api_app_worker_add_del_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->app_index = clib_net_to_host_u32(a->app_index);
    a->wrk_index = clib_net_to_host_u32(a->wrk_index);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_app_worker_add_del_reply_t_endian (vl_api_app_worker_add_del_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->wrk_index = clib_net_to_host_u32(a->wrk_index);
    a->app_event_queue_address = clib_net_to_host_u64(a->app_event_queue_address);
    /* a->n_fds = a->n_fds (no-op) */
    /* a->fd_flags = a->fd_flags (no-op) */
    /* a->segment_name_length = a->segment_name_length (no-op) */
    /* a->segment_name = a->segment_name (no-op) */
    a->segment_handle = clib_net_to_host_u64(a->segment_handle);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_session_enable_disable_t_endian (vl_api_session_enable_disable_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_enable = a->is_enable (no-op) */
}

static inline void vl_api_session_enable_disable_reply_t_endian (vl_api_session_enable_disable_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_app_namespace_add_del_t_endian (vl_api_app_namespace_add_del_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->secret = clib_net_to_host_u64(a->secret);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->ip4_fib_id = clib_net_to_host_u32(a->ip4_fib_id);
    a->ip6_fib_id = clib_net_to_host_u32(a->ip6_fib_id);
    /* a->namespace_id_len = a->namespace_id_len (no-op) */
    /* a->namespace_id = a->namespace_id (no-op) */
}

static inline void vl_api_app_namespace_add_del_reply_t_endian (vl_api_app_namespace_add_del_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->appns_index = clib_net_to_host_u32(a->appns_index);
}

static inline void vl_api_session_rule_add_del_t_endian (vl_api_session_rule_add_del_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->transport_proto = a->transport_proto (no-op) */
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->lcl_ip = a->lcl_ip (no-op) */
    /* a->lcl_plen = a->lcl_plen (no-op) */
    /* a->rmt_ip = a->rmt_ip (no-op) */
    /* a->rmt_plen = a->rmt_plen (no-op) */
    a->lcl_port = clib_net_to_host_u16(a->lcl_port);
    a->rmt_port = clib_net_to_host_u16(a->rmt_port);
    a->action_index = clib_net_to_host_u32(a->action_index);
    /* a->is_add = a->is_add (no-op) */
    a->appns_index = clib_net_to_host_u32(a->appns_index);
    /* a->scope = a->scope (no-op) */
    /* a->tag = a->tag (no-op) */
}

static inline void vl_api_session_rule_add_del_reply_t_endian (vl_api_session_rule_add_del_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_session_rules_dump_t_endian (vl_api_session_rules_dump_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_session_rules_details_t_endian (vl_api_session_rules_details_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->transport_proto = a->transport_proto (no-op) */
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->lcl_ip = a->lcl_ip (no-op) */
    /* a->lcl_plen = a->lcl_plen (no-op) */
    /* a->rmt_ip = a->rmt_ip (no-op) */
    /* a->rmt_plen = a->rmt_plen (no-op) */
    a->lcl_port = clib_net_to_host_u16(a->lcl_port);
    a->rmt_port = clib_net_to_host_u16(a->rmt_port);
    a->action_index = clib_net_to_host_u32(a->action_index);
    a->appns_index = clib_net_to_host_u32(a->appns_index);
    /* a->scope = a->scope (no-op) */
    /* a->tag = a->tag (no-op) */
}


#endif
#endif /* vl_endianfun */

/****** Version tuple *****/

#ifdef vl_api_version_tuple


#endif /* vl_api_version_tuple */

/****** API CRC (whole file) *****/

#ifdef vl_api_version
vl_api_version(session.api, 0xdf888b15)

#endif


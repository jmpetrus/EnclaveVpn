/*
 * VLIB API definitions 2021-09-27 00:01:44
 * Input file: tapv2.api
 * Automatically generated: please edit the input file NOT this file!
 */

#include <stdbool.h>
#if defined(vl_msg_id)||defined(vl_union_id) \
    || defined(vl_printfun) ||defined(vl_endianfun) \
    || defined(vl_api_version)||defined(vl_typedefs) \
    || defined(vl_msg_name)||defined(vl_msg_name_crc_list) \
    || defined(vl_api_version_tuple)
/* ok, something was selected */
#else
#warning no content included from tapv2.api
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))
/* Imported API files */
#ifndef vl_api_version
#endif

/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_TAP_CREATE_V2, vl_api_tap_create_v2_t_handler)
vl_msg_id(VL_API_TAP_CREATE_V2_REPLY, vl_api_tap_create_v2_reply_t_handler)
vl_msg_id(VL_API_TAP_DELETE_V2, vl_api_tap_delete_v2_t_handler)
vl_msg_id(VL_API_TAP_DELETE_V2_REPLY, vl_api_tap_delete_v2_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_TAP_V2_DUMP, vl_api_sw_interface_tap_v2_dump_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_TAP_V2_DETAILS, vl_api_sw_interface_tap_v2_details_t_handler)
#endif
/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_tap_create_v2_t, 1)
vl_msg_name(vl_api_tap_create_v2_reply_t, 1)
vl_msg_name(vl_api_tap_delete_v2_t, 1)
vl_msg_name(vl_api_tap_delete_v2_reply_t, 1)
vl_msg_name(vl_api_sw_interface_tap_v2_dump_t, 1)
vl_msg_name(vl_api_sw_interface_tap_v2_details_t, 1)
#endif
/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_tapv2 \
_(VL_API_TAP_CREATE_V2, tap_create_v2, 8fa99320) \
_(VL_API_TAP_CREATE_V2_REPLY, tap_create_v2_reply, fda5941f) \
_(VL_API_TAP_DELETE_V2, tap_delete_v2, 529cb13f) \
_(VL_API_TAP_DELETE_V2_REPLY, tap_delete_v2_reply, e8d4e804) \
_(VL_API_SW_INTERFACE_TAP_V2_DUMP, sw_interface_tap_v2_dump, 51077d14) \
_(VL_API_SW_INTERFACE_TAP_V2_DETAILS, sw_interface_tap_v2_details, 5ee87a5f) 
#endif
/****** Typedefs ******/

#ifdef vl_typedefs
#include "tapv2.api_types.h"
#endif
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_tapv2_printfun_types
#define included_tapv2_printfun_types


#endif
#endif /* vl_printfun_types */
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_tapv2_printfun
#define included_tapv2_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_tap_create_v2_t_print (vl_api_tap_create_v2_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_tap_create_v2_t: */
    s = format(s, "vl_api_tap_create_v2_t:");
    s = format(s, "\n%Uid: %u", format_white_space, indent, a->id);
    s = format(s, "\n%Uuse_random_mac: %u", format_white_space, indent, a->use_random_mac);
    s = format(s, "\n%Umac_address: %U", format_white_space, indent, format_hex_bytes, a, 6);
    s = format(s, "\n%Utx_ring_sz: %u", format_white_space, indent, a->tx_ring_sz);
    s = format(s, "\n%Urx_ring_sz: %u", format_white_space, indent, a->rx_ring_sz);
    s = format(s, "\n%Uhost_namespace_set: %u", format_white_space, indent, a->host_namespace_set);
    s = format(s, "\n%Uhost_namespace: %U", format_white_space, indent, format_hex_bytes, a, 64);
    s = format(s, "\n%Uhost_mac_addr_set: %u", format_white_space, indent, a->host_mac_addr_set);
    s = format(s, "\n%Uhost_mac_addr: %U", format_white_space, indent, format_hex_bytes, a, 6);
    s = format(s, "\n%Uhost_if_name_set: %u", format_white_space, indent, a->host_if_name_set);
    s = format(s, "\n%Uhost_if_name: %U", format_white_space, indent, format_hex_bytes, a, 64);
    s = format(s, "\n%Uhost_bridge_set: %u", format_white_space, indent, a->host_bridge_set);
    s = format(s, "\n%Uhost_bridge: %U", format_white_space, indent, format_hex_bytes, a, 64);
    s = format(s, "\n%Uhost_ip4_addr_set: %u", format_white_space, indent, a->host_ip4_addr_set);
    s = format(s, "\n%Uhost_ip4_addr: %U", format_white_space, indent, format_hex_bytes, a, 4);
    s = format(s, "\n%Uhost_ip4_prefix_len: %u", format_white_space, indent, a->host_ip4_prefix_len);
    s = format(s, "\n%Uhost_ip6_addr_set: %u", format_white_space, indent, a->host_ip6_addr_set);
    s = format(s, "\n%Uhost_ip6_addr: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Uhost_ip6_prefix_len: %u", format_white_space, indent, a->host_ip6_prefix_len);
    s = format(s, "\n%Uhost_ip4_gw_set: %u", format_white_space, indent, a->host_ip4_gw_set);
    s = format(s, "\n%Uhost_ip4_gw: %U", format_white_space, indent, format_hex_bytes, a, 4);
    s = format(s, "\n%Uhost_ip6_gw_set: %u", format_white_space, indent, a->host_ip6_gw_set);
    s = format(s, "\n%Uhost_ip6_gw: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Uhost_mtu_set: %u", format_white_space, indent, a->host_mtu_set);
    s = format(s, "\n%Uhost_mtu_size: %u", format_white_space, indent, a->host_mtu_size);
    s = format(s, "\n%Utag: %U", format_white_space, indent, format_hex_bytes, a, 64);
    s = format(s, "\n%Utap_flags: %u", format_white_space, indent, a->tap_flags);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_tap_create_v2_reply_t_print (vl_api_tap_create_v2_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_tap_create_v2_reply_t: */
    s = format(s, "vl_api_tap_create_v2_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Usw_if_index: %u", format_white_space, indent, a->sw_if_index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_tap_delete_v2_t_print (vl_api_tap_delete_v2_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_tap_delete_v2_t: */
    s = format(s, "vl_api_tap_delete_v2_t:");
    s = format(s, "\n%Usw_if_index: %u", format_white_space, indent, a->sw_if_index);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_tap_delete_v2_reply_t_print (vl_api_tap_delete_v2_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_tap_delete_v2_reply_t: */
    s = format(s, "vl_api_tap_delete_v2_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_sw_interface_tap_v2_dump_t_print (vl_api_sw_interface_tap_v2_dump_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_sw_interface_tap_v2_dump_t: */
    s = format(s, "vl_api_sw_interface_tap_v2_dump_t:");
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_sw_interface_tap_v2_details_t_print (vl_api_sw_interface_tap_v2_details_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_sw_interface_tap_v2_details_t: */
    s = format(s, "vl_api_sw_interface_tap_v2_details_t:");
    s = format(s, "\n%Usw_if_index: %u", format_white_space, indent, a->sw_if_index);
    s = format(s, "\n%Uid: %u", format_white_space, indent, a->id);
    s = format(s, "\n%Udev_name: %U", format_white_space, indent, format_hex_bytes, a, 64);
    s = format(s, "\n%Utx_ring_sz: %u", format_white_space, indent, a->tx_ring_sz);
    s = format(s, "\n%Urx_ring_sz: %u", format_white_space, indent, a->rx_ring_sz);
    s = format(s, "\n%Uhost_mac_addr: %U", format_white_space, indent, format_hex_bytes, a, 6);
    s = format(s, "\n%Uhost_if_name: %U", format_white_space, indent, format_hex_bytes, a, 64);
    s = format(s, "\n%Uhost_namespace: %U", format_white_space, indent, format_hex_bytes, a, 64);
    s = format(s, "\n%Uhost_bridge: %U", format_white_space, indent, format_hex_bytes, a, 64);
    s = format(s, "\n%Uhost_ip4_addr: %U", format_white_space, indent, format_hex_bytes, a, 4);
    s = format(s, "\n%Uhost_ip4_prefix_len: %u", format_white_space, indent, a->host_ip4_prefix_len);
    s = format(s, "\n%Uhost_ip6_addr: %U", format_white_space, indent, format_hex_bytes, a, 16);
    s = format(s, "\n%Uhost_ip6_prefix_len: %u", format_white_space, indent, a->host_ip6_prefix_len);
    s = format(s, "\n%Uhost_mtu_size: %u", format_white_space, indent, a->host_mtu_size);
    s = format(s, "\n%Utap_flags: %u", format_white_space, indent, a->tap_flags);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}


#endif
#endif /* vl_printfun */

/****** Endian swap functions *****/
#ifdef vl_endianfun
#ifndef included_tapv2_endianfun
#define included_tapv2_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_tap_create_v2_t_endian (vl_api_tap_create_v2_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->id = clib_net_to_host_u32(a->id);
    /* a->use_random_mac = a->use_random_mac (no-op) */
    /* a->mac_address = a->mac_address (no-op) */
    a->tx_ring_sz = clib_net_to_host_u16(a->tx_ring_sz);
    a->rx_ring_sz = clib_net_to_host_u16(a->rx_ring_sz);
    /* a->host_namespace_set = a->host_namespace_set (no-op) */
    /* a->host_namespace = a->host_namespace (no-op) */
    /* a->host_mac_addr_set = a->host_mac_addr_set (no-op) */
    /* a->host_mac_addr = a->host_mac_addr (no-op) */
    /* a->host_if_name_set = a->host_if_name_set (no-op) */
    /* a->host_if_name = a->host_if_name (no-op) */
    /* a->host_bridge_set = a->host_bridge_set (no-op) */
    /* a->host_bridge = a->host_bridge (no-op) */
    /* a->host_ip4_addr_set = a->host_ip4_addr_set (no-op) */
    /* a->host_ip4_addr = a->host_ip4_addr (no-op) */
    /* a->host_ip4_prefix_len = a->host_ip4_prefix_len (no-op) */
    /* a->host_ip6_addr_set = a->host_ip6_addr_set (no-op) */
    /* a->host_ip6_addr = a->host_ip6_addr (no-op) */
    /* a->host_ip6_prefix_len = a->host_ip6_prefix_len (no-op) */
    /* a->host_ip4_gw_set = a->host_ip4_gw_set (no-op) */
    /* a->host_ip4_gw = a->host_ip4_gw (no-op) */
    /* a->host_ip6_gw_set = a->host_ip6_gw_set (no-op) */
    /* a->host_ip6_gw = a->host_ip6_gw (no-op) */
    /* a->host_mtu_set = a->host_mtu_set (no-op) */
    a->host_mtu_size = clib_net_to_host_u32(a->host_mtu_size);
    /* a->tag = a->tag (no-op) */
    a->tap_flags = clib_net_to_host_u32(a->tap_flags);
}

static inline void vl_api_tap_create_v2_reply_t_endian (vl_api_tap_create_v2_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_tap_delete_v2_t_endian (vl_api_tap_delete_v2_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_tap_delete_v2_reply_t_endian (vl_api_tap_delete_v2_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_tap_v2_dump_t_endian (vl_api_sw_interface_tap_v2_dump_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_sw_interface_tap_v2_details_t_endian (vl_api_sw_interface_tap_v2_details_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->id = clib_net_to_host_u32(a->id);
    /* a->dev_name = a->dev_name (no-op) */
    a->tx_ring_sz = clib_net_to_host_u16(a->tx_ring_sz);
    a->rx_ring_sz = clib_net_to_host_u16(a->rx_ring_sz);
    /* a->host_mac_addr = a->host_mac_addr (no-op) */
    /* a->host_if_name = a->host_if_name (no-op) */
    /* a->host_namespace = a->host_namespace (no-op) */
    /* a->host_bridge = a->host_bridge (no-op) */
    /* a->host_ip4_addr = a->host_ip4_addr (no-op) */
    /* a->host_ip4_prefix_len = a->host_ip4_prefix_len (no-op) */
    /* a->host_ip6_addr = a->host_ip6_addr (no-op) */
    /* a->host_ip6_prefix_len = a->host_ip6_prefix_len (no-op) */
    a->host_mtu_size = clib_net_to_host_u32(a->host_mtu_size);
    a->tap_flags = clib_net_to_host_u32(a->tap_flags);
}


#endif
#endif /* vl_endianfun */

/****** Version tuple *****/

#ifdef vl_api_version_tuple


#endif /* vl_api_version_tuple */

/****** API CRC (whole file) *****/

#ifdef vl_api_version
vl_api_version(tapv2.api, 0x41375eca)

#endif


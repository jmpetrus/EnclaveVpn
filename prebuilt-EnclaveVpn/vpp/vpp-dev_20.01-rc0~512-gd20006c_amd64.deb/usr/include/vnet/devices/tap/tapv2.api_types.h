#ifndef included_tapv2_api_types_h
#define included_tapv2_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_tap_create_v2 {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 id;
    u8 use_random_mac;
    u8 mac_address[6];
    u16 tx_ring_sz;
    u16 rx_ring_sz;
    u8 host_namespace_set;
    u8 host_namespace[64];
    u8 host_mac_addr_set;
    u8 host_mac_addr[6];
    u8 host_if_name_set;
    u8 host_if_name[64];
    u8 host_bridge_set;
    u8 host_bridge[64];
    u8 host_ip4_addr_set;
    u8 host_ip4_addr[4];
    u8 host_ip4_prefix_len;
    u8 host_ip6_addr_set;
    u8 host_ip6_addr[16];
    u8 host_ip6_prefix_len;
    u8 host_ip4_gw_set;
    u8 host_ip4_gw[4];
    u8 host_ip6_gw_set;
    u8 host_ip6_gw[16];
    u8 host_mtu_set;
    u32 host_mtu_size;
    u8 tag[64];
    u32 tap_flags;
} vl_api_tap_create_v2_t;
typedef struct __attribute__ ((packed)) _vl_api_tap_create_v2_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
} vl_api_tap_create_v2_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_tap_delete_v2 {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
} vl_api_tap_delete_v2_t;
typedef struct __attribute__ ((packed)) _vl_api_tap_delete_v2_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_tap_delete_v2_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_tap_v2_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_sw_interface_tap_v2_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_tap_v2_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u32 id;
    u8 dev_name[64];
    u16 tx_ring_sz;
    u16 rx_ring_sz;
    u8 host_mac_addr[6];
    u8 host_if_name[64];
    u8 host_namespace[64];
    u8 host_bridge[64];
    u8 host_ip4_addr[4];
    u8 host_ip4_prefix_len;
    u8 host_ip6_addr[16];
    u8 host_ip6_prefix_len;
    u32 host_mtu_size;
    u32 tap_flags;
} vl_api_sw_interface_tap_v2_details_t;

#endif

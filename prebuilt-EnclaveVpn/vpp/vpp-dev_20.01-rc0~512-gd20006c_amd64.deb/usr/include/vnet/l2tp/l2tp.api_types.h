#ifndef included_l2tp_api_types_h
#define included_l2tp_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_l2tpv3_create_tunnel {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 client_address[16];
    u8 our_address[16];
    u8 is_ipv6;
    u32 local_session_id;
    u32 remote_session_id;
    u64 local_cookie;
    u64 remote_cookie;
    u8 l2_sublayer_present;
    u32 encap_vrf_id;
} vl_api_l2tpv3_create_tunnel_t;
typedef struct __attribute__ ((packed)) _vl_api_l2tpv3_create_tunnel_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
} vl_api_l2tpv3_create_tunnel_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2tpv3_set_tunnel_cookies {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u64 new_local_cookie;
    u64 new_remote_cookie;
} vl_api_l2tpv3_set_tunnel_cookies_t;
typedef struct __attribute__ ((packed)) _vl_api_l2tpv3_set_tunnel_cookies_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2tpv3_set_tunnel_cookies_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_if_l2tpv3_tunnel_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u8 interface_name[64];
    u8 client_address[16];
    u8 our_address[16];
    u32 local_session_id;
    u32 remote_session_id;
    u64 local_cookie[2];
    u64 remote_cookie;
    u8 l2_sublayer_present;
} vl_api_sw_if_l2tpv3_tunnel_details_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_if_l2tpv3_tunnel_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_sw_if_l2tpv3_tunnel_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_l2tpv3_interface_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 enable_disable;
    u32 sw_if_index;
} vl_api_l2tpv3_interface_enable_disable_t;
typedef struct __attribute__ ((packed)) _vl_api_l2tpv3_interface_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2tpv3_interface_enable_disable_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2tpv3_set_lookup_key {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 key;
} vl_api_l2tpv3_set_lookup_key_t;
typedef struct __attribute__ ((packed)) _vl_api_l2tpv3_set_lookup_key_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2tpv3_set_lookup_key_reply_t;

#endif

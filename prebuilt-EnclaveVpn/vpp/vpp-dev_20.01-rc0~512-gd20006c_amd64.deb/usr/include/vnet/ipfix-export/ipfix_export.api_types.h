#ifndef included_ipfix_export_api_types_h
#define included_ipfix_export_api_types_h
/* Imported API files */
#include <vnet/ip/ip_types.api_types.h>
typedef struct __attribute__ ((packed)) _vl_api_set_ipfix_exporter {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_address_t collector_address;
    u16 collector_port;
    vl_api_address_t src_address;
    u32 vrf_id;
    u32 path_mtu;
    u32 template_interval;
    bool udp_checksum;
} vl_api_set_ipfix_exporter_t;
typedef struct __attribute__ ((packed)) _vl_api_set_ipfix_exporter_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_set_ipfix_exporter_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_exporter_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_ipfix_exporter_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_exporter_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_address_t collector_address;
    u16 collector_port;
    vl_api_address_t src_address;
    u32 vrf_id;
    u32 path_mtu;
    u32 template_interval;
    bool udp_checksum;
} vl_api_ipfix_exporter_details_t;
typedef struct __attribute__ ((packed)) _vl_api_set_ipfix_classify_stream {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 domain_id;
    u16 src_port;
} vl_api_set_ipfix_classify_stream_t;
typedef struct __attribute__ ((packed)) _vl_api_set_ipfix_classify_stream_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_set_ipfix_classify_stream_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_classify_stream_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_ipfix_classify_stream_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_classify_stream_details {
    u16 _vl_msg_id;
    u32 context;
    u32 domain_id;
    u16 src_port;
} vl_api_ipfix_classify_stream_details_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_classify_table_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 table_id;
    vl_api_address_family_t ip_version;
    vl_api_ip_proto_t transport_protocol;
    bool is_add;
} vl_api_ipfix_classify_table_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_classify_table_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipfix_classify_table_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_classify_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_ipfix_classify_table_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_classify_table_details {
    u16 _vl_msg_id;
    u32 context;
    u32 table_id;
    vl_api_address_family_t ip_version;
    vl_api_ip_proto_t transport_protocol;
} vl_api_ipfix_classify_table_details_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_flush {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_ipfix_flush_t;
typedef struct __attribute__ ((packed)) _vl_api_ipfix_flush_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_ipfix_flush_reply_t;

#endif

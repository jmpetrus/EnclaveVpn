#ifndef included_ethernet_types_api_types_h
#define included_ethernet_types_api_types_h
typedef u8 vl_api_mac_address_t[6];

#endif

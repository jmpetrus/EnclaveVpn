#ifndef included_l2_api_types_h
#define included_l2_api_types_h
/* Imported API files */
#include <vnet/ip/ip_types.api_types.h>
#include <vnet/ethernet/ethernet_types.api_types.h>
typedef struct __attribute__ ((packed)) _vl_api_mac_entry {
    u32 sw_if_index;
    u8 mac_addr[6];
    u8 action;
    u8 flags;
} vl_api_mac_entry_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_domain_sw_if {
    u32 context;
    u32 sw_if_index;
    u8 shg;
} vl_api_bridge_domain_sw_if_t;
typedef enum {
    BRIDGE_API_FLAG_NONE = 0,
    BRIDGE_API_FLAG_LEARN = 1,
    BRIDGE_API_FLAG_FWD = 2,
    BRIDGE_API_FLAG_FLOOD = 4,
    BRIDGE_API_FLAG_UU_FLOOD = 8,
    BRIDGE_API_FLAG_ARP_TERM = 16,
    BRIDGE_API_FLAG_ARP_UFWD = 32,
} vl_api_bd_flags_t;
typedef enum {
    L2_API_PORT_TYPE_NORMAL = 0,
    L2_API_PORT_TYPE_BVI = 1,
    L2_API_PORT_TYPE_UU_FWD = 2,
} vl_api_l2_port_type_t;
typedef struct __attribute__ ((packed)) _vl_api_bd_ip_mac {
    u32 bd_id;
    vl_api_address_t ip;
    vl_api_mac_address_t mac;
} vl_api_bd_ip_mac_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_xconnect_details {
    u16 _vl_msg_id;
    u32 context;
    u32 rx_sw_if_index;
    u32 tx_sw_if_index;
} vl_api_l2_xconnect_details_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_xconnect_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_l2_xconnect_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_fib_table_details {
    u16 _vl_msg_id;
    u32 context;
    u32 bd_id;
    u8 mac[6];
    u32 sw_if_index;
    u8 static_mac;
    u8 filter_mac;
    u8 bvi_mac;
} vl_api_l2_fib_table_details_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_fib_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
} vl_api_l2_fib_table_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_fib_clear_table {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_l2_fib_clear_table_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_fib_clear_table_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2_fib_clear_table_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2fib_flush_all {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_l2fib_flush_all_t;
typedef struct __attribute__ ((packed)) _vl_api_l2fib_flush_all_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2fib_flush_all_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2fib_flush_bd {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
} vl_api_l2fib_flush_bd_t;
typedef struct __attribute__ ((packed)) _vl_api_l2fib_flush_bd_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2fib_flush_bd_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2fib_flush_int {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
} vl_api_l2fib_flush_int_t;
typedef struct __attribute__ ((packed)) _vl_api_l2fib_flush_int_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2fib_flush_int_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2fib_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mac[6];
    u32 bd_id;
    u32 sw_if_index;
    u8 is_add;
    u8 static_mac;
    u8 filter_mac;
    u8 bvi_mac;
} vl_api_l2fib_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_l2fib_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2fib_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_want_l2_macs_events {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 learn_limit;
    u8 scan_delay;
    u8 max_macs_in_event;
    u8 enable_disable;
    u32 pid;
} vl_api_want_l2_macs_events_t;
typedef struct __attribute__ ((packed)) _vl_api_want_l2_macs_events_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_want_l2_macs_events_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_macs_event {
    u16 _vl_msg_id;
    u32 client_index;
    u32 pid;
    u32 n_macs;
    vl_api_mac_entry_t mac[0];
} vl_api_l2_macs_event_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_flags {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_set;
    u32 feature_bitmap;
} vl_api_l2_flags_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_flags_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 resulting_feature_bitmap;
} vl_api_l2_flags_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_domain_set_mac_age {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
    u8 mac_age;
} vl_api_bridge_domain_set_mac_age_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_domain_set_mac_age_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_bridge_domain_set_mac_age_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_domain_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
    u8 flood;
    u8 uu_flood;
    u8 forward;
    u8 learn;
    u8 arp_term;
    u8 arp_ufwd;
    u8 mac_age;
    u8 bd_tag[64];
    u8 is_add;
} vl_api_bridge_domain_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_domain_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_bridge_domain_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_domain_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
} vl_api_bridge_domain_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_domain_details {
    u16 _vl_msg_id;
    u32 context;
    u32 bd_id;
    u8 flood;
    u8 uu_flood;
    u8 forward;
    u8 learn;
    u8 arp_term;
    u8 arp_ufwd;
    u8 mac_age;
    u8 bd_tag[64];
    u32 bvi_sw_if_index;
    u32 uu_fwd_sw_if_index;
    u32 n_sw_ifs;
    vl_api_bridge_domain_sw_if_t sw_if_details[0];
} vl_api_bridge_domain_details_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_flags {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
    u8 is_set;
    vl_api_bd_flags_t flags;
} vl_api_bridge_flags_t;
typedef struct __attribute__ ((packed)) _vl_api_bridge_flags_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 resulting_feature_bitmap;
} vl_api_bridge_flags_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_interface_vlan_tag_rewrite {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 vtr_op;
    u32 push_dot1q;
    u32 tag1;
    u32 tag2;
} vl_api_l2_interface_vlan_tag_rewrite_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_interface_vlan_tag_rewrite_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2_interface_vlan_tag_rewrite_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_interface_pbb_tag_rewrite {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 vtr_op;
    u16 outer_tag;
    u8 b_dmac[6];
    u8 b_smac[6];
    u16 b_vlanid;
    u32 i_sid;
} vl_api_l2_interface_pbb_tag_rewrite_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_interface_pbb_tag_rewrite_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2_interface_pbb_tag_rewrite_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_patch_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 rx_sw_if_index;
    u32 tx_sw_if_index;
    u8 is_add;
} vl_api_l2_patch_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_patch_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2_patch_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_l2_xconnect {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 rx_sw_if_index;
    u32 tx_sw_if_index;
    u8 enable;
} vl_api_sw_interface_set_l2_xconnect_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_l2_xconnect_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sw_interface_set_l2_xconnect_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_l2_bridge {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 rx_sw_if_index;
    u32 bd_id;
    vl_api_l2_port_type_t port_type;
    u8 shg;
    u8 enable;
} vl_api_sw_interface_set_l2_bridge_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_l2_bridge_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sw_interface_set_l2_bridge_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bd_ip_mac_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    vl_api_bd_ip_mac_t entry;
} vl_api_bd_ip_mac_add_del_t;
typedef struct __attribute__ ((packed)) _vl_api_bd_ip_mac_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_bd_ip_mac_add_del_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bd_ip_mac_flush {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
} vl_api_bd_ip_mac_flush_t;
typedef struct __attribute__ ((packed)) _vl_api_bd_ip_mac_flush_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_bd_ip_mac_flush_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bd_ip_mac_details {
    u16 _vl_msg_id;
    u32 context;
    vl_api_bd_ip_mac_t entry;
} vl_api_bd_ip_mac_details_t;
typedef struct __attribute__ ((packed)) _vl_api_bd_ip_mac_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
} vl_api_bd_ip_mac_dump_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_interface_efp_filter {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 enable_disable;
} vl_api_l2_interface_efp_filter_t;
typedef struct __attribute__ ((packed)) _vl_api_l2_interface_efp_filter_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_l2_interface_efp_filter_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_vpath {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 enable;
} vl_api_sw_interface_set_vpath_t;
typedef struct __attribute__ ((packed)) _vl_api_sw_interface_set_vpath_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sw_interface_set_vpath_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bvi_create {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_mac_address_t mac;
    u32 user_instance;
} vl_api_bvi_create_t;
typedef struct __attribute__ ((packed)) _vl_api_bvi_create_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
} vl_api_bvi_create_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_bvi_delete {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
} vl_api_bvi_delete_t;
typedef struct __attribute__ ((packed)) _vl_api_bvi_delete_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_bvi_delete_reply_t;

#endif

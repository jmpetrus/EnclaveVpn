#ifndef __included__home_sgx_vpp_build_root_build_vpp_native_vpp_plugins_acl_acl_types_api_json
#define __included__home_sgx_vpp_build_root_build_vpp_native_vpp_plugins_acl_acl_types_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>


#define DEFINE_VAPI_MSG_IDS_ACL_TYPES_API_JSON\



#ifndef defined_vapi_type_acl_rule
#define defined_vapi_type_acl_rule
typedef struct __attribute__((__packed__)) {
  u8 is_permit;
  u8 is_ipv6;
  u8 src_ip_addr[16];
  u8 src_ip_prefix_len;
  u8 dst_ip_addr[16];
  u8 dst_ip_prefix_len;
  u8 proto;
  u16 srcport_or_icmptype_first;
  u16 srcport_or_icmptype_last;
  u16 dstport_or_icmpcode_first;
  u16 dstport_or_icmpcode_last;
  u8 tcp_flags_mask;
  u8 tcp_flags_value;
} vapi_type_acl_rule;

static inline void vapi_type_acl_rule_hton(vapi_type_acl_rule *msg)
{
  msg->srcport_or_icmptype_first = htobe16(msg->srcport_or_icmptype_first);
  msg->srcport_or_icmptype_last = htobe16(msg->srcport_or_icmptype_last);
  msg->dstport_or_icmpcode_first = htobe16(msg->dstport_or_icmpcode_first);
  msg->dstport_or_icmpcode_last = htobe16(msg->dstport_or_icmpcode_last);
}

static inline void vapi_type_acl_rule_ntoh(vapi_type_acl_rule *msg)
{
  msg->srcport_or_icmptype_first = be16toh(msg->srcport_or_icmptype_first);
  msg->srcport_or_icmptype_last = be16toh(msg->srcport_or_icmptype_last);
  msg->dstport_or_icmpcode_first = be16toh(msg->dstport_or_icmpcode_first);
  msg->dstport_or_icmpcode_last = be16toh(msg->dstport_or_icmpcode_last);
}
#endif

#ifndef defined_vapi_type_macip_acl_rule
#define defined_vapi_type_macip_acl_rule
typedef struct __attribute__((__packed__)) {
  u8 is_permit;
  u8 is_ipv6;
  u8 src_mac[6];
  u8 src_mac_mask[6];
  u8 src_ip_addr[16];
  u8 src_ip_prefix_len;
} vapi_type_macip_acl_rule;

static inline void vapi_type_macip_acl_rule_hton(vapi_type_macip_acl_rule *msg)
{

}

static inline void vapi_type_macip_acl_rule_ntoh(vapi_type_macip_acl_rule *msg)
{

}
#endif


#ifdef __cplusplus
}
#endif

#endif

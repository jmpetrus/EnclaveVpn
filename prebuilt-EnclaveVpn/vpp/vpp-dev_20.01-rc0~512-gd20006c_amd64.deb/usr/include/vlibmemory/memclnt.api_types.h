#ifndef included_memclnt_api_types_h
#define included_memclnt_api_types_h
typedef struct __attribute__ ((packed)) _vl_api_module_version {
    u32 major;
    u32 minor;
    u32 patch;
    u8 name[64];
} vl_api_module_version_t;
typedef struct __attribute__ ((packed)) _vl_api_message_table_entry {
    u16 index;
    u8 name[64];
} vl_api_message_table_entry_t;
typedef struct __attribute__ ((packed)) _vl_api_memclnt_create {
    u16 _vl_msg_id;
    u32 context;
    i32 ctx_quota;
    u64 input_queue;
    u8 name[64];
    u32 api_versions[8];
} vl_api_memclnt_create_t;
typedef struct __attribute__ ((packed)) _vl_api_memclnt_create_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 response;
    u64 handle;
    u32 index;
    u64 message_table;
} vl_api_memclnt_create_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_memclnt_delete {
    u16 _vl_msg_id;
    u32 index;
    u64 handle;
    u8 do_cleanup;
} vl_api_memclnt_delete_t;
typedef struct __attribute__ ((packed)) _vl_api_memclnt_delete_reply {
    u16 _vl_msg_id;
    i32 response;
    u64 handle;
} vl_api_memclnt_delete_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_rx_thread_exit {
    u16 _vl_msg_id;
    u8 dummy;
} vl_api_rx_thread_exit_t;
typedef struct __attribute__ ((packed)) _vl_api_memclnt_rx_thread_suspend {
    u16 _vl_msg_id;
    u8 dummy;
} vl_api_memclnt_rx_thread_suspend_t;
typedef struct __attribute__ ((packed)) _vl_api_memclnt_read_timeout {
    u16 _vl_msg_id;
    u8 dummy;
} vl_api_memclnt_read_timeout_t;
typedef struct __attribute__ ((packed)) _vl_api_rpc_call {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 function;
    u8 multicast;
    u8 need_barrier_sync;
    u8 send_reply;
    u32 data_len;
    u8 data[0];
} vl_api_rpc_call_t;
typedef struct __attribute__ ((packed)) _vl_api_rpc_call_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_rpc_call_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_get_first_msg_id {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
} vl_api_get_first_msg_id_t;
typedef struct __attribute__ ((packed)) _vl_api_get_first_msg_id_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u16 first_msg_id;
} vl_api_get_first_msg_id_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_api_versions {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_api_versions_t;
typedef struct __attribute__ ((packed)) _vl_api_api_versions_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_module_version_t api_versions[0];
} vl_api_api_versions_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_trace_plugin_msg_ids {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 plugin_name[128];
    u16 first_msg_id;
    u16 last_msg_id;
} vl_api_trace_plugin_msg_ids_t;
typedef struct __attribute__ ((packed)) _vl_api_sockclnt_create {
    u16 _vl_msg_id;
    u32 context;
    u8 name[64];
} vl_api_sockclnt_create_t;
typedef struct __attribute__ ((packed)) _vl_api_sockclnt_create_reply {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    i32 response;
    u32 index;
    u16 count;
    vl_api_message_table_entry_t message_table[0];
} vl_api_sockclnt_create_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sockclnt_delete {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 index;
} vl_api_sockclnt_delete_t;
typedef struct __attribute__ ((packed)) _vl_api_sockclnt_delete_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 response;
} vl_api_sockclnt_delete_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_sock_init_shm {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 requested_size;
    u8 nitems;
    u64 configs[0];
} vl_api_sock_init_shm_t;
typedef struct __attribute__ ((packed)) _vl_api_sock_init_shm_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_sock_init_shm_reply_t;
typedef struct __attribute__ ((packed)) _vl_api_memclnt_keepalive {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
} vl_api_memclnt_keepalive_t;
typedef struct __attribute__ ((packed)) _vl_api_memclnt_keepalive_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
} vl_api_memclnt_keepalive_reply_t;

#endif
